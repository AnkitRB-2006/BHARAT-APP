<?php
session_start();
include 'db.php';

// If already logged in, skip login page
if (isset($_SESSION['admin_id'])) {
    header("Location: admin-dashboard.php");
    exit();
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    // Check if admin exists
    $result = $conn->query("SELECT * FROM admins WHERE email = '$email'");

    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();
        // Verify hashed password
        if (password_verify($password, $admin['password'])) {
            // Set session variables
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['full_name'];
            $_SESSION['is_admin'] = true;

            header("Location: admin-dashboard.php");
            exit();
        } else {
            $error = "Invalid password. Please try again.";
        }
    } else {
        $error = "No admin account found with that email.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Bharat App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #001f3f 0%, #000b18 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 24px;
            padding: 50px;
            width: 100%;
            max-width: 420px;
            box-shadow: 0 25px 50px rgba(0,0,0,0.5);
        }
        .brand-logo {
            font-size: 2rem;
            font-weight: 700;
            color: #fff;
            text-align: center;
            margin-bottom: 10px;
        }
        .brand-logo span { color: #ff9933; }
        .form-label { color: rgba(255,255,255,0.7); font-size: 0.85rem; font-weight: 600; }
        .form-control {
            background: rgba(255,255,255,0.08);
            border: 1px solid rgba(255,255,255,0.1);
            color: #fff;
            border-radius: 12px;
            padding: 12px 15px;
        }
        .form-control:focus {
            background: rgba(255,255,255,0.12);
            color: #fff;
            border-color: #ff9933;
            box-shadow: 0 0 0 4px rgba(255, 153, 51, 0.2);
        }
        .btn-login {
            background: #ff9933;
            border: none;
            color: #000;
            font-weight: 700;
            border-radius: 12px;
            padding: 14px;
            width: 100%;
            margin-top: 20px;
            transition: 0.3s;
        }
        .btn-login:hover {
            background: #ffae5e;
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(255, 153, 51, 0.3);
        }
        .error-box {
            background: rgba(220, 53, 69, 0.2);
            color: #ff8c94;
            padding: 12px;
            border-radius: 10px;
            font-size: 0.85rem;
            margin-bottom: 20px;
            text-align: center;
            border: 1px solid rgba(220, 53, 69, 0.3);
        }
    </style>
</head>
<body>

<div class="login-card">
    <div class="brand-logo">☁️ Bharat <span>Admin</span></div>
    <p class="text-center text-white-50 small mb-4">Authorized Personnel Only</p>

    <?php if ($error): ?>
        <div class="error-box"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">ADMIN EMAIL</label>
            <input type="email" name="email" class="form-control" placeholder="admin@bharatapp.com" required>
        </div>
        <div class="mb-4">
            <label class="form-label">PASSWORD</label>
            <input type="password" name="password" class="form-control" placeholder="••••••••" required>
        </div>
        <button type="submit" class="btn btn-login">ACCESS DASHBOARD</button>
    </form>
    
    <div class="mt-4 text-center">
        <a href="index.php" class="text-white-50 text-decoration-none small">← Back to Main Site</a>
    </div>
</div>

</body>
</html>