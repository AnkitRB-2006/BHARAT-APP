<?php 
session_start();
include 'db.php'; // Include DB to save the order
include 'includes/header.php';

$is_plus = isset($_SESSION['is_plus_member']) && $_SESSION['is_plus_member'] == true;

// --- PROCESS THE ORDER ---
$total = 0;
$has_uphaar = false;

// 1. Calculate final total from the cart before clearing it
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    $subtotal = 0;
    foreach ($_SESSION['cart'] as $item) {
        $subtotal += $item['price'] * $item['quantity'];
        if (isset($item['service_type']) && $item['service_type'] == 'uphaar') {
            $has_uphaar = true;
        }
    }
    
    $delivery_fee = ($is_plus) ? 0 : 40;
    $total = $subtotal + $delivery_fee;
    
    // 2. Insert the order into the database so the Admin Hub can see it
    // If user is logged in, use their ID. Otherwise, save as guest (NULL or 0 depending on your DB config)
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : NULL; 
    
    if ($user_id) {
        $stmt = $conn->prepare("INSERT INTO orders (user_id, total, status) VALUES (?, ?, 'Pending')");
        $stmt->bind_param("id", $user_id, $total);
        $stmt->execute();
        $db_order_id = $stmt->insert_id;
        $order_id = "BH-" . sprintf('%05d', $db_order_id); // Looks like BH-00014
    } else {
        $order_id = "BH-" . rand(10000, 99999); // Fallback for guests
    }

    // 3. Clear the cart now that the order is placed!
    unset($_SESSION['cart']);

} else {
    // If someone just types success.php in the URL without buying anything
    $order_id = "BH-" . rand(10000, 99999);
}

$savings = $is_plus ? 60 : 0; // Example: 40 (Delivery) + 20 (Gift Wrap)
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>

<style>
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f4f6f9;
    }

    .success-icon-wrapper {
        width: 100px;
        height: 100px;
        background: #e8f5e9;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto;
        box-shadow: 0 10px 20px rgba(76, 175, 80, 0.2);
        animation: scaleIn 0.5s ease-out forwards;
    }

    .success-icon {
        font-size: 3.5rem;
        color: #4CAF50;
    }

    @keyframes scaleIn {
        0% { transform: scale(0); opacity: 0; }
        70% { transform: scale(1.1); }
        100% { transform: scale(1); opacity: 1; }
    }

    .summary-card {
        background: white;
        border: none;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        overflow: hidden;
    }

    .btn-bharat {
        background: linear-gradient(45deg, #ff9933, #ff5e62);
        color: white;
        font-weight: 600;
        border: none;
        border-radius: 30px;
        padding: 12px 30px;
        transition: 0.3s;
    }
    .btn-bharat:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(255, 153, 51, 0.3);
        color: white;
    }

    .btn-outline-dark {
        border-radius: 30px;
        padding: 12px 30px;
        font-weight: 600;
        transition: 0.3s;
    }
</style>

<div class="container py-5 text-center mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            
            <div class="mb-5">
                <div class="success-icon-wrapper mb-4">
                    <i class="bi bi-check-lg success-icon"></i>
                </div>
                <h2 class="fw-bold text-dark">Order Placed Successfully!</h2>
                <p class="text-muted fs-5">Thank you for shopping with Bharat App.</p>
            </div>

            <div class="summary-card p-4 mb-4 text-start">
                <div class="d-flex justify-content-between align-items-center mb-4 pb-3 border-bottom">
                    <div>
                        <span class="text-muted small d-block">Order ID</span>
                        <span class="fw-bold fs-5 text-dark"><?php echo $order_id; ?></span>
                    </div>
                    <div class="text-end">
                        <span class="text-muted small d-block">Amount Paid</span>
                        <span class="fw-bold fs-5 text-success">₹<?php echo number_format($total, 2); ?></span>
                    </div>
                </div>

                <div class="d-flex justify-content-between small mb-3">
                    <span class="text-muted"><i class="bi bi-clock me-2"></i> Estimated Delivery</span>
                    <span class="fw-bold text-dark">24 - 35 mins</span>
                </div>
                <div class="d-flex justify-content-between small mb-3">
                    <span class="text-muted"><i class="bi bi-geo-alt me-2"></i> Delivery Location</span>
                    <span class="fw-bold text-dark">Default Saved Address</span>
                </div>
                
                <?php if($is_plus && $savings > 0): ?>
                <div class="mt-4 p-3 rounded-4" style="background: linear-gradient(135deg, #fef9e7 0%, #fff 100%); border: 1px solid #ffe082;">
                    <h6 class="text-warning fw-bold mb-3" style="color: #f57f17 !important;">
                        <i class="bi bi-stars"></i> Bharat Plus Savings
                    </h6>
                    <div class="d-flex justify-content-between small mb-2 text-muted">
                        <span>Free Delivery</span>
                        <span class="text-success fw-medium">-₹40.00</span>
                    </div>
                    <?php if($has_uphaar): ?>
                    <div class="d-flex justify-content-between small mb-2 text-muted">
                        <span>Premium Gift Wrapping</span>
                        <span class="text-success fw-medium">-₹20.00</span>
                    </div>
                    <?php endif; ?>
                    <hr class="border-warning opacity-25">
                    <div class="d-flex justify-content-between fw-bold">
                        <span class="text-dark">Total Saved Today</span>
                        <span class="text-success fs-5">₹<?php echo number_format($savings, 2); ?></span>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <div class="d-grid gap-3">
                <a href="account.php" class="btn btn-bharat shadow-sm"><i class="bi bi-box-seam me-2"></i>Track Order Status</a>
                <a href="index.php" class="btn btn-outline-dark"><i class="bi bi-house-door me-2"></i>Back to Home</a>
            </div>
            
            <p class="mt-5 small text-muted">
                Need help with your order? <br>
                <a href="#" class="text-orange text-decoration-none fw-bold"><i class="bi bi-telephone me-1"></i> Contact Support (1800-123-4567)</a>
            </p>
        </div>
    </div>
</div>

<script>
    // Trigger celebration confetti on load
    window.onload = function() {
        var duration = 3 * 1000;
        var end = Date.now() + duration;

        (function frame() {
            confetti({
                particleCount: 5,
                angle: 60,
                spread: 55,
                origin: { x: 0 },
                colors: ['#4CAF50', '#FF9933', '#FFD700']
            });
            confetti({
                particleCount: 5,
                angle: 120,
                spread: 55,
                origin: { x: 1 },
                colors: ['#4CAF50', '#FF9933', '#FFD700']
            });

            if (Date.now() < end) {
                requestAnimationFrame(frame);
            }
        }());
    };
</script>

<?php include 'includes/footer.php'; ?>