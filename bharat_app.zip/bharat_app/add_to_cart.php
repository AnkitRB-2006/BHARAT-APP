<?php
session_start();
include 'db.php'; // Include database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['product_id'])) {
    
    // 1. Get the product ID securely
    $product_id = (int)$_POST['product_id'];
    
    // 2. Fetch the REAL product details from the database (Prevents price hacking via Inspect Element)
    $stmt = $conn->prepare("SELECT name, price, service_type, image_path FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // 3. If the product exists, add it to the cart
    if ($result && $result->num_rows > 0) {
        $product = $result->fetch_assoc();
        
        // Initialize cart if it doesn't exist
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        // Check if product is already in cart to increase quantity
        if (isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id]['quantity'] += 1;
        } else {
            // Add new product to cart with secure DB data
            $_SESSION['cart'][$product_id] = [
                'name' => $product['name'],
                'price' => $product['price'],
                'service_type' => $product['service_type'], // Required for the Gift Wrap feature in cart.php!
                'image_path' => $product['image_path'],
                'quantity' => 1
            ];
        }
    }

    // 4. Redirect back to the page the user was just on
    if (isset($_SERVER['HTTP_REFERER'])) {
        header("Location: " . $_SERVER['HTTP_REFERER']);
    } else {
        // Fallback just in case the browser blocks the referer
        header("Location: index.php"); 
    }
    exit();
} else {
    // If accessed directly without POST data, send home
    header("Location: index.php");
    exit();
}
?>