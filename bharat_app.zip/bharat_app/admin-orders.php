<?php
require_once 'admin_auth.php';
include 'db.php';

// --- 1. HANDLE STATUS UPDATE ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_order'])) {
    $status = $_POST['status'];
    $order_id = (int)$_POST['order_id'];
    $stmt = $conn->prepare("UPDATE orders SET status=? WHERE id=?");
    $stmt->bind_param("si", $status, $order_id);
    if ($stmt->execute()) {
        $success_msg = "Order #BH-" . sprintf('%05d', $order_id) . " updated to $status.";
    }
}

// --- 2. HANDLE FILTERS & SEARCH ---
$filter = $_GET['filter'] ?? 'All';
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

$query_str = "SELECT orders.*, users.full_name, users.email 
              FROM orders 
              LEFT JOIN users ON orders.user_id = users.id 
              WHERE 1=1";

if ($filter !== 'All') {
    $query_str .= " AND status = '$filter'";
}

if (!empty($search)) {
    $query_str .= " AND (users.full_name LIKE '%$search%' OR orders.id LIKE '%$search%')";
}

$query_str .= " ORDER BY created_at DESC";
$orders = $conn->query($query_str);

// --- 3. COUNT STATS ---
$pending_count = $conn->query("SELECT COUNT(*) as c FROM orders WHERE status='Pending'")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Management - Admin Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f4f7f6; font-family: 'Poppins', sans-serif; }
        
        .admin-nav { background: linear-gradient(135deg, #001f3f 0%, #00152a 100%); padding: 15px 0; }
        .admin-nav .nav-link { color: rgba(255, 255, 255, 0.7) !important; font-weight: 500; margin: 0 5px; padding: 8px 16px; border-radius: 8px; transition: 0.3s; }
        .admin-nav .nav-link:hover { color: #ffffff !important; background: rgba(255, 255, 255, 0.1); }
        .admin-nav .active { color: #ff9933 !important; background: rgba(255, 153, 51, 0.1); }

        .table-card { background: white; border-radius: 24px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.02); border: 1px solid #e9ecef; }
        
        /* Filter Tabs */
        .nav-pills .nav-link { border-radius: 30px; padding: 8px 20px; color: #6c757d; font-weight: 500; border: 1px solid transparent; }
        .nav-pills .nav-link.active { background-color: #002147 !important; color: white !important; }
        .nav-pills .nav-link:hover:not(.active) { background-color: #f8f9fa; border-color: #dee2e6; }

        .status-select { border-radius: 10px; font-size: 0.85rem; font-weight: 500; }
        .btn-update { border-radius: 10px; font-weight: 600; padding: 5px 15px; }
        
        .search-box { border-radius: 15px; padding: 10px 20px; border: 1px solid #e9ecef; box-shadow: 0 4px 12px rgba(0,0,0,0.02); }
    </style>
</head>
<body>

<nav class="admin-nav shadow-sm mb-5">
    <div class="container d-flex justify-content-between align-items-center">
        <a class="navbar-brand text-white fw-bold fs-4" href="index.php"><i class="bi bi-cloud-fill me-2" style="color: #ff9933;"></i>Bharat App</a>
        <div class="d-flex align-items-center">
            <a class="nav-link" href="admin-dashboard.php">Dashboard</a>
            <a class="nav-link active" href="admin-orders.php">Manage Orders</a>
            <a class="nav-link" href="admin-products.php">Inventory</a>
            <a class="nav-link text-danger ms-3" href="admin_auth.php?logout=true" style="background: rgba(220,53,69,0.1);"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </div>
    </div>
</nav>

<div class="container py-4">
    
    <?php if(isset($success_msg)): ?>
        <div class="alert alert-success alert-dismissible fade show border-0 rounded-4 shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> <?php echo $success_msg; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-5 gap-3">
        <div>
            <h2 class="fw-bold mb-0 text-dark">Live Orders</h2>
            <p class="text-muted mb-0">You have <span class="text-primary fw-bold"><?php echo $pending_count; ?> pending</span> orders to process.</p>
        </div>
        <form method="GET" class="d-flex gap-2">
            <input type="text" name="search" class="form-control search-box" placeholder="Order ID or Name..." value="<?php echo htmlspecialchars($search); ?>">
            <button class="btn btn-dark rounded-pill px-4">Search</button>
        </form>
    </div>

    <ul class="nav nav-pills mb-4 gap-2">
        <li class="nav-item">
            <a class="nav-link <?php echo ($filter == 'All') ? 'active' : ''; ?>" href="admin-orders.php?filter=All">All Orders</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo ($filter == 'Pending') ? 'active' : ''; ?>" href="admin-orders.php?filter=Pending">Pending</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo ($filter == 'Shipped') ? 'active' : ''; ?>" href="admin-orders.php?filter=Shipped">Shipped</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo ($filter == 'Delivered') ? 'active' : ''; ?>" href="admin-orders.php?filter=Delivered">Delivered</a>
        </li>
    </ul>

    <div class="table-card">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="text-muted small text-uppercase bg-light">
                    <tr>
                        <th class="ps-3 py-3 border-0 rounded-start">ID</th>
                        <th class="py-3 border-0">Customer Info</th>
                        <th class="py-3 border-0">Timestamp</th>
                        <th class="py-3 border-0 text-center">Status</th>
                        <th class="py-3 border-0">Total</th>
                        <th class="text-end pe-3 py-3 border-0 rounded-end">Quick Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($orders && $orders->num_rows > 0): ?>
                        <?php while($row = $orders->fetch_assoc()): 
                            $status_class = ($row['status'] == 'Delivered') ? 'bg-success' : (($row['status'] == 'Shipped') ? 'bg-info text-dark' : 'bg-warning text-dark');
                        ?>
                        <tr>
                            <td class="ps-3 fw-bold text-dark">#BH-<?php echo sprintf('%05d', $row['id']); ?></td>
                            <td>
                                <div class="fw-bold text-dark"><?php echo htmlspecialchars($row['full_name'] ?? 'Guest User'); ?></div>
                                <small class="text-muted"><?php echo htmlspecialchars($row['email'] ?? 'No email provided'); ?></small>
                            </td>
                            <td>
                                <div class="small fw-medium"><?php echo date('M d, Y', strtotime($row['created_at'])); ?></div>
                                <div class="text-muted" style="font-size: 0.75rem;"><?php echo date('h:i A', strtotime($row['created_at'])); ?></div>
                            </td>
                            <td class="text-center">
                                <span class="badge rounded-pill <?php echo $status_class; ?> px-3 py-2 fw-medium">
                                    <?php echo $row['status']; ?>
                                </span>
                            </td>
                            <td class="fw-bold text-dark">₹<?php echo number_format($row['total'], 2); ?></td>
                            <td class="text-end pe-3">
                                <form method="POST" class="d-flex justify-content-end gap-2">
                                    <input type="hidden" name="order_id" value="<?php echo $row['id']; ?>">
                                    <input type="hidden" name="update_order" value="1">
                                    <select name="status" class="form-select form-select-sm status-select" style="width: 120px;">
                                        <option value="Pending" <?php if($row['status']=='Pending') echo 'selected'; ?>>Pending</option>
                                        <option value="Shipped" <?php if($row['status']=='Shipped') echo 'selected'; ?>>Shipped</option>
                                        <option value="Delivered" <?php if($row['status']=='Delivered') echo 'selected'; ?>>Delivered</option>
                                    </select>
                                    <button class="btn btn-sm btn-dark btn-update">Update</button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center py-5">
                                <div class="display-1 text-muted opacity-25 mb-3"><i class="bi bi-cart-x"></i></div>
                                <h5 class="fw-bold text-dark">No orders found</h5>
                                <p class="text-muted small">Try changing your filters or checking back later.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>