<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'db.php';

// --- 1. HANDLE LOGIN SUBMISSION ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['admin_login'])) {
    $email = $conn->real_escape_string($_POST['email']);
    $pass = $_POST['password'];

    // Search for the admin in the database
    $result = $conn->query("SELECT * FROM admins WHERE email = '$email'");

    if ($result && $result->num_rows > 0) {
        $admin = $result->fetch_assoc();
        
        // Verify the hashed password from the DB against the typed password
        if (password_verify($pass, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['full_name'];
            $_SESSION['admin_logged_in'] = true;
            
            header("Location: admin-dashboard.php");
            exit();
        } else {
            $error = "Incorrect password!";
        }
    } else {
        $error = "No admin found with that email!";
    }
}

// --- 2. HANDLE LOGOUT ---
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: admin_auth.php");
    exit();
}

// --- 3. SHOW LOGIN FORM IF NOT LOGGED IN ---
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Authentication - Bharat App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body { 
            background: linear-gradient(135deg, #001f3f 0%, #080d16 100%); 
            height: 100vh; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-family: 'Poppins', sans-serif;
        }
        .login-card { 
            background: rgba(255, 255, 255, 0.05); 
            backdrop-filter: blur(15px);
            padding: 40px; 
            border-radius: 24px; 
            width: 100%; 
            max-width: 400px; 
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: white;
        }
        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: white;
            border-radius: 12px;
            padding: 12px;
        }
        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            color: white;
            border-color: #ff9933;
            box-shadow: 0 0 0 0.25rem rgba(255, 153, 51, 0.25);
        }
        .btn-admin {
            background: #ff9933;
            color: #000;
            font-weight: 600;
            border: none;
            border-radius: 12px;
            padding: 12px;
            transition: 0.3s;
        }
        .btn-admin:hover {
            background: #ffae5e;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="login-card shadow-2xl">
        <div class="text-center mb-4">
            <h3 class="fw-bold mb-1">Bharat <span style="color: #ff9933;">Admin</span></h3>
            <p class="small text-white-50">Please sign in to your dashboard</p>
        </div>

        <?php if(isset($error)): ?>
            <div class="alert alert-danger py-2 border-0 bg-danger bg-opacity-25 text-white small" style="border-radius: 10px;">
                <i class="bi bi-exclamation-circle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="small fw-bold text-white-50 mb-2">EMAIL ADDRESS</label>
                <input type="email" name="email" class="form-control" placeholder="admin@bharatapp.com" required>
            </div>
            <div class="mb-4">
                <label class="small fw-bold text-white-50 mb-2">PASSWORD</label>
                <input type="password" name="password" class="form-control" placeholder="••••••••" required>
            </div>
            <button type="submit" name="admin_login" class="btn btn-admin w-100">Access Dashboard</button>
        </form>
        
        <div class="text-center mt-4">
            <a href="index.php" class="text-white-50 text-decoration-none small">← Back to Homepage</a>
        </div>
    </div>
</body>
</html>
<?php
    exit(); 
}
?>