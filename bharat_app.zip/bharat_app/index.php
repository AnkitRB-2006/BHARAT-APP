<?php 
session_start(); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bharat App - India's Super App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        /* CORE STYLES */
        body {
            font-family: 'Times New Roman', Times, serif;
            background-color: #0f1014; /* Deep dark background */
            color: #ffffff; /* Strict white text */
            overflow-x: hidden;
        }

        :root {
            --brand-orange: #ff9933; 
            --card-bg: rgba(255, 255, 255, 0.05);
            --card-hover: rgba(255, 255, 255, 0.1);
        }

        /* TYPOGRAPHY & COLORS */
        .text-orange { color: var(--brand-orange) !important; }
        .text-light-muted { color: rgba(255, 255, 255, 0.6) !important; }
        
        /* NAVBAR */
        .navbar {
            background: rgba(15, 16, 20, 0.8) !important;
            backdrop-filter: blur(15px);
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        .navbar-brand { font-size: 1.8rem; font-weight: bold; color: #ffffff !important; }
        .nav-link { color: #ffffff !important; transition: 0.3s; }
        .nav-link:hover { color: var(--brand-orange) !important; }
        .dropdown-menu { background-color: #1a1b20; border: 1px solid rgba(255,255,255,0.1); }
        .dropdown-item { color: #ffffff; }
        .dropdown-item:hover { background-color: rgba(255,255,255,0.1); color: var(--brand-orange); }

        /* BUTTONS */
        .btn-bharat {
            background: linear-gradient(45deg, #ff9933, #e68a00);
            color: white !important;
            border: none;
            border-radius: 30px;
            padding: 10px 25px;
            transition: all 0.3s ease;
            font-weight: bold;
        }
        .btn-bharat:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 20px rgba(255, 153, 51, 0.4);
        }
        .btn-outline-light { border-radius: 30px; padding: 10px 25px; }

        /* HERO SECTION */
        .hero-section {
            padding: 120px 0 80px;
            position: relative;
            text-align: center;
        }
        .hero-glow {
            position: absolute;
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            width: 600px; height: 600px;
            background: radial-gradient(circle, rgba(255,153,51,0.15) 0%, rgba(15,16,20,0) 70%);
            z-index: -1;
        }
        .display-3 { font-weight: 700; letter-spacing: 1px; }

        /* SERVICE CARDS (Glassmorphism) */
        .service-card {
            background: var(--card-bg);
            border: 1px solid rgba(255,255,255,0.05);
            border-radius: 24px;
            padding: 30px;
            text-align: center;
            text-decoration: none;
            color: #ffffff;
            display: block;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            backdrop-filter: blur(10px);
        }
        .service-card:hover {
            transform: translateY(-10px);
            background: var(--card-hover);
            border-color: var(--brand-orange);
            color: #ffffff;
            box-shadow: 0 15px 30px rgba(0,0,0,0.5);
        }
        .service-icon { font-size: 3rem; margin-bottom: 15px; display: inline-block; transition: 0.3s; }
        .service-card:hover .service-icon { transform: scale(1.1); }

        /* EXCLUSIVE OFFERS */
        .offer-card {
            background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.01) 100%);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 20px;
            padding: 30px;
            transition: 0.3s;
        }
        .offer-card:hover { border-color: rgba(255,255,255,0.3); }

        /* INTERACTIVE FOOTER */
        .interactive-footer {
            background-color: #0a0a0c;
            border-top: 1px solid rgba(255,255,255,0.05);
            padding: 60px 0 30px;
            margin-top: 80px;
        }
        .footer-link {
            color: rgba(255,255,255,0.6);
            text-decoration: none;
            transition: 0.3s;
            display: inline-block;
        }
        .footer-link:hover {
            color: var(--brand-orange);
            transform: translateX(5px);
        }
        .social-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 45px; height: 45px;
            background: rgba(255,255,255,0.05);
            border-radius: 50%;
            color: white;
            font-size: 1.2rem;
            transition: all 0.3s ease;
        }
        .social-icon:hover {
            background: var(--brand-orange);
            transform: translateY(-5px) rotate(360deg);
        }
        .newsletter-input {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            color: white;
            border-radius: 30px 0 0 30px;
        }
        .newsletter-input:focus {
            background: rgba(255,255,255,0.1);
            color: white;
            box-shadow: none;
            border-color: var(--brand-orange);
        }
        .newsletter-btn {
            border-radius: 0 30px 30px 0;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top py-3">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="index.php">
            <div style="background: var(--brand-orange); width: 35px; height: 35px; border-radius: 8px; display: flex; align-items: center; justify-content: center; margin-right: 12px; font-family: sans-serif;">B</div>
            Bharat App
        </a>
        
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="bi bi-list text-white fs-1"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center gap-3">
                <li class="nav-item">
                    <a class="nav-link fw-bold text-orange" href="admin-dashboard.php">⚙️ Admin Hub</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-bold" href="partner.php">Partner with us</a>
                </li>
                
                <?php if(isset($_SESSION['user_id'])): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle btn btn-outline-light px-4" href="#" data-bs-toggle="dropdown" style="border-radius: 30px;">
                            👤 <?php echo explode(' ', $_SESSION['full_name'])[0]; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow">
                            <li><a class="dropdown-item py-2" href="account.php">📊 Dashboard</a></li>
                            <li><a class="dropdown-item py-2" href="cart.php">🛒 My Cart</a></li>
                            <li><hr class="dropdown-divider border-secondary"></li>
                            <li><a class="dropdown-item py-2 text-danger" href="auth.php?action=logout">🚪 Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="btn btn-bharat" href="auth.php">Login / Sign Up</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="hero-section">
    <div class="hero-glow"></div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <span class="badge bg-dark border border-secondary px-3 py-2 rounded-pill mb-4" style="font-size: 0.9rem;">
                    ✨ Discover the Premium Experience
                </span>
                <h1 class="display-3 mb-4">
                    Your Daily Life,<br>
                    <span class="text-orange">Elegantly Simplified.</span>
                </h1>
                <p class="lead text-light-muted mb-5 px-md-5">
                    From instant rides to midnight cravings, groceries to premium gifts — experience the power of everything in one unified space.
                </p>
                <div class="d-flex justify-content-center gap-3">
                    <a href="yatra.php" class="btn btn-bharat btn-lg shadow-lg">Explore Yatra →</a>
                    <a href="bazaar.php" class="btn btn-outline-light btn-lg">Shop Bazaar</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-end mb-5 border-bottom border-secondary pb-3">
        <div>
            <h2 class="fw-bold mb-1">Premium Services</h2>
            <p class="text-light-muted mb-0">Explore our growing ecosystem curated for you.</p>
        </div>
    </div>

    <div class="row g-4">
        <?php
        $services = [
            ['link' => 'yatra.php', 'name' => 'Yatra', 'desc' => 'Autos, Cabs & Bikes', 'icon' => '🚕'],
            ['link' => 'aahar.php', 'name' => 'Aahar', 'desc' => 'Gourmet Delivery', 'icon' => '🍲'],
            ['link' => 'kirana.php', 'name' => 'Kirana', 'desc' => 'Fresh Groceries', 'icon' => '🥦'],
            ['link' => 'bazaar.php', 'name' => 'Bazaar', 'desc' => 'Fashion & Tech', 'icon' => '🛍️'],
            ['link' => 'seva.php', 'name' => 'Seva', 'desc' => 'Elite Home Services', 'icon' => '🧹'],
            ['link' => 'dawai.php', 'name' => 'Dawai', 'desc' => '24/7 Medicines', 'icon' => '💊'],
            ['link' => 'uphaar.php', 'name' => 'Uphaar', 'desc' => 'Luxury Gifting', 'icon' => '🎀'],
            ['link' => 'plus.php', 'name' => 'Bharat Plus', 'desc' => 'VIP Membership', 'icon' => '💎']
        ];
        foreach ($services as $s): ?>
        <div class="col-6 col-md-4 col-lg-3">
            <a href="<?php echo $s['link']; ?>" class="service-card">
                <span class="service-icon"><?php echo $s['icon']; ?></span>
                <h4 class="fw-bold mb-2"><?php echo $s['name']; ?></h4>
                <p class="text-light-muted small mb-0"><?php echo $s['desc']; ?></p>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="container py-5 mb-5">
    <h2 class="fw-bold mb-4">Exclusive Curations</h2>
    <div class="row g-4">
        <div class="col-md-6">
            <div class="offer-card d-flex align-items-center justify-content-between h-100">
                <div>
                    <span class="badge bg-danger mb-3 px-3 py-2 rounded-pill">New User</span>
                    <h3 class="fw-bold">50% OFF on Aahar</h3>
                    <p class="text-light-muted mb-0">Use Code: <span class="text-white fw-bold">BHARAT50</span></p>
                </div>
                <div style="font-size: 4rem;">🍕</div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="offer-card d-flex align-items-center justify-content-between h-100">
                <div>
                    <span class="badge bg-success mb-3 px-3 py-2 rounded-pill">Yatra Priority</span>
                    <h3 class="fw-bold">Complimentary Ride</h3>
                    <p class="text-light-muted mb-0">Valid on Premium Bike Taxis today.</p>
                </div>
                <div style="font-size: 4rem;">🛵</div>
            </div>
        </div>
    </div>
</div>

<footer class="interactive-footer">
    <div class="container">
        <div class="row g-5 mb-5">
            <div class="col-lg-4">
                <h3 class="fw-bold mb-4">
                    <span style="color: var(--brand-orange);">B</span>harat App
                </h3>
                <p class="text-light-muted mb-4">Redefining convenience with a touch of elegance. Your premium destination for daily needs.</p>
                <div class="d-flex gap-3">
                    <a href="#" class="social-icon"><i class="bi bi-twitter-x"></i></a>
                    <a href="#" class="social-icon"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="social-icon"><i class="bi bi-linkedin"></i></a>
                </div>
            </div>
            
            <div class="col-lg-2 col-6">
                <h5 class="fw-bold mb-4">Company</h5>
                <ul class="list-unstyled d-flex flex-column gap-3">
                    <li><a href="#" class="footer-link">About Us</a></li>
                    <li><a href="partner.php" class="footer-link">Careers</a></li>
                    <li><a href="#" class="footer-link">Press</a></li>
                </ul>
            </div>
            
            <div class="col-lg-2 col-6">
                <h5 class="fw-bold mb-4">Support</h5>
                <ul class="list-unstyled d-flex flex-column gap-3">
                    <li><a href="#" class="footer-link">Help Center</a></li>
                    <li><a href="#" class="footer-link">Safety</a></li>
                    <li><a href="#" class="footer-link">Terms of Service</a></li>
                </ul>
            </div>

            <div class="col-lg-4">
                <h5 class="fw-bold mb-4">Stay Updated</h5>
                <p class="text-light-muted small mb-3">Subscribe to our newsletter for the latest exclusive offers.</p>
                <div class="input-group mb-3 shadow-sm">
                    <input type="email" class="form-control newsletter-input" placeholder="Enter your email">
                    <button class="btn btn-bharat newsletter-btn px-4" type="button">Subscribe</button>
                </div>
            </div>
        </div>
        
        <div class="border-top border-secondary pt-4 d-flex flex-column flex-md-row justify-content-between align-items-center">
            <small class="text-light-muted">&copy; <?php echo date('Y'); ?> Bharat App. Designed with precision.</small>
            <div class="mt-3 mt-md-0 d-flex gap-3">
                <small class="text-light-muted">Privacy Policy</small>
                <small class="text-light-muted">Cookie Policy</small>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>