<?php 
session_start();
include 'db.php'; // Connect to database to fetch live gifts
include 'includes/header.php'; 
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #fcf8fa; /* Soft pink-tinted background */
    }

    /* Vibrant Uphaar Hero Section */
    .uphaar-hero {
        background: linear-gradient(135deg, #FF416C 0%, #FF4B2B 100%);
        color: white;
        padding: 60px 20px;
        border-radius: 0 0 40px 40px;
        margin-top: -20px;
        box-shadow: 0 10px 30px rgba(255, 65, 108, 0.2);
    }

    /* Search Bar Styling */
    .search-bar {
        background: rgba(255, 255, 255, 0.2);
        border: 2px solid rgba(255, 255, 255, 0.5);
        color: white;
        backdrop-filter: blur(10px);
    }
    .search-bar::placeholder { color: rgba(255, 255, 255, 0.9); }
    .search-bar:focus { background: white; color: #333; border-color: white; box-shadow: none; }

    /* Modern Gift Cards */
    .gift-card {
        border: none;
        border-radius: 20px;
        background: white;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(255, 65, 108, 0.05);
    }
    .gift-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(255, 65, 108, 0.15);
    }

    /* Image Styling & Animation */
    .img-container {
        width: 100%;
        height: 220px;
        overflow: hidden;
        position: relative;
        background-color: #fff0f5;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .product-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }
    .gift-card:hover .product-img {
        transform: scale(1.1);
    }

    /* Filter Buttons */
    .filter-btn {
        border-radius: 30px;
        padding: 8px 24px;
        font-weight: 500;
        transition: all 0.3s;
        border: 1px solid #dee2e6;
        color: #495057;
        background: white;
    }
    .filter-btn:hover {
        background-color: #fff0f5;
        color: #D81B60;
        border-color: #D81B60;
    }
    .filter-btn.active { 
        background-color: #D81B60; 
        color: white; 
        border-color: #D81B60; 
    }

    /* Custom Add Button */
    .btn-add {
        color: #D81B60;
        border: 2px solid #D81B60;
        border-radius: 20px;
        font-weight: 600;
        padding: 4px 16px;
        background: transparent;
        transition: 0.3s;
    }
    .btn-add:hover {
        background: #D81B60;
        color: white;
        transform: scale(1.05);
    }
</style>

<div class="uphaar-hero mb-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-7">
                <span class="badge bg-white text-danger mb-2 px-3 py-2 rounded-pill fw-bold">🎁 Same-Day Delivery</span>
                <h1 class="fw-bold mb-2 display-5"><i class="bi bi-gift"></i> Uphaar</h1>
                <p class="fs-5 opacity-75 mb-0">Send love with premium gifts, chocolates & fresh flowers.</p>
            </div>
            <div class="col-md-5 mt-4 mt-md-0">
                <div class="input-group">
                    <span class="input-group-text bg-transparent border-0 text-white fs-4 position-absolute" style="z-index: 10; left: 10px; top: 2px;"><i class="bi bi-search"></i></span>
                    <input type="text" class="form-control form-control-lg rounded-pill search-bar ps-5" placeholder="Search cakes, flowers, hampers...">
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mb-5">
    
    <div class="d-flex gap-2 mb-4 overflow-auto pb-2" style="white-space: nowrap;">
        <button class="btn filter-btn active"><i class="bi bi-grid-fill me-1"></i> All Gifts</button>
        <button class="btn filter-btn"><i class="bi bi-flower1 me-1"></i> Flowers</button>
        <button class="btn filter-btn"><i class="bi bi-box2-heart me-1"></i> Hampers</button>
        <button class="btn filter-btn">🍫 Chocolates</button>
        <button class="btn filter-btn">🧸 Soft Toys</button>
        <button class="btn filter-btn">🎂 Cakes</button>
    </div>

    <div class="row g-4">
        <?php
        // Fetch dynamic products from the database for Uphaar
        $query = "SELECT * FROM products WHERE service_type = 'uphaar'";
        $result = $conn->query($query);

        if ($result && $result->num_rows > 0): 
            while ($f = $result->fetch_assoc()): 
                // Image handling: Use DB image, or a premium gifting fallback image
                $img_src = (!empty($f['image_path']) && $f['image_path'] != 'uploads/default.png') 
                            ? $f['image_path'] 
                            : 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=600&q=80'; // Gift/Celebration fallback
        ?>
        <div class="col-md-6 col-lg-3">
            <div class="card gift-card h-100 d-flex flex-column">
                
                <div class="img-container">
                    <span class="badge bg-danger position-absolute top-0 start-0 m-3 z-3 shadow-sm rounded-pill px-3 py-2"><i class="bi bi-heart-fill"></i> Best Seller</span>
                    <img src="<?php echo htmlspecialchars($img_src); ?>" class="product-img" alt="<?php echo htmlspecialchars($f['name']); ?>" onerror="this.src='https://via.placeholder.com/400x400?text=No+Image'">
                </div>
                
                <div class="card-body p-3 d-flex flex-column">
                    <h6 class="fw-bold mb-1 text-dark" style="font-size: 1.05rem; line-height: 1.3;"><?php echo htmlspecialchars($f['name']); ?></h6>
                    
                    <p class="small text-muted mb-3 flex-grow-1 line-clamp">
                        <?php echo htmlspecialchars($f['description'] ?? 'A perfect gift for your loved ones.'); ?>
                    </p>
                    
                    <div class="d-flex align-items-center justify-content-between mt-auto pt-2 border-top">
                        <div>
                            <span class="fw-bold fs-5" style="color: #D81B60;">₹<?php echo number_format($f['price'], 0); ?></span>
                        </div>
                        
                        <form action="add_to_cart.php" method="POST" class="m-0">
                            <input type="hidden" name="product_id" value="<?php echo $f['id']; ?>">
                            <input type="hidden" name="name" value="<?php echo htmlspecialchars($f['name']); ?>">
                            <input type="hidden" name="price" value="<?php echo $f['price']; ?>">
                            <button type="submit" class="btn btn-add shadow-sm">+ Add</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php 
            endwhile; 
        else: 
        ?>
            <div class="col-12 text-center py-5 mt-4 bg-white rounded-4 shadow-sm">
                <div class="display-1 text-muted opacity-25 mb-3">🎁</div>
                <h4 class="fw-bold text-dark">No gifts available right now</h4>
                <p class="text-muted">Head over to the Admin Hub to stock up on flowers, chocolates, and hampers!</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>