<?php 
session_start();
// Include your database connection so we can fetch live products
include 'db.php'; 
include 'includes/header.php'; 
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f4f6f9;
    }

    /* Vibrant Hero Section */
    .aahar-hero {
        background: linear-gradient(135deg, #ff6a00 0%, #ee0979 100%);
        color: white;
        padding: 60px 20px;
        border-radius: 0 0 40px 40px;
        margin-top: -20px; /* Pulls it up snug against the navbar */
        box-shadow: 0 10px 30px rgba(238, 9, 121, 0.2);
    }

    /* Search Bar Styling */
    .search-bar {
        background: rgba(255, 255, 255, 0.2);
        border: 2px solid rgba(255, 255, 255, 0.5);
        color: white;
        backdrop-filter: blur(10px);
    }
    .search-bar::placeholder { color: rgba(255, 255, 255, 0.8); }
    .search-bar:focus { background: white; color: #333; border-color: white; box-shadow: none; }

    /* Filter Buttons */
    .filter-btn {
        border-radius: 30px;
        padding: 8px 24px;
        font-weight: 500;
        transition: all 0.3s;
    }
    .filter-btn.active { background-color: #333; color: white; border-color: #333; }

    /* Modern Food Cards */
    .food-card {
        border: none;
        border-radius: 20px;
        background: white;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    }
    .food-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(238, 9, 121, 0.15);
    }

    /* Image Styling & Animation */
    .img-container {
        width: 100%;
        height: 220px;
        overflow: hidden;
        position: relative;
        background-color: #f8f9fa;
    }
    .product-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }
    .food-card:hover .product-img {
        transform: scale(1.1); /* Slight zoom on hover */
    }

    /* Badges */
    .food-badge {
        position: absolute;
        top: 15px;
        left: 15px;
        background: rgba(255, 255, 255, 0.9);
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        z-index: 2;
    }

    /* Custom Add Button */
    .btn-add {
        color: #ee0979;
        border: 2px solid #ee0979;
        border-radius: 20px;
        font-weight: 600;
        padding: 4px 16px;
        background: transparent;
        transition: 0.3s;
    }
    .btn-add:hover {
        background: #ee0979;
        color: white;
        transform: scale(1.05);
    }
</style>

<div class="aahar-hero mb-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-7">
                <h1 class="fw-bold mb-2 display-5"><i class="bi bi-fire"></i> Aahar Delivery</h1>
                <p class="fs-5 opacity-75 mb-0">Craving something delicious? We'll get it to you fast.</p>
            </div>
            <div class="col-md-5 mt-4 mt-md-0">
                <div class="input-group">
                    <span class="input-group-text bg-transparent border-0 text-white fs-4 position-absolute" style="z-index: 10; left: 10px; top: 2px;"><i class="bi bi-search"></i></span>
                    <input type="text" class="form-control form-control-lg rounded-pill search-bar ps-5" placeholder="Search for biryani, pizza, dosa...">
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mb-5">
    <div class="d-flex flex-wrap gap-2 mb-4">
        <button class="btn btn-outline-dark filter-btn active">All Dishes</button>
        <button class="btn btn-outline-success filter-btn"><i class="bi bi-record-circle text-success"></i> Veg Only</button>
        <button class="btn btn-outline-danger filter-btn"><i class="bi bi-caret-up-square text-danger"></i> Non-Veg</button>
        <button class="btn btn-outline-secondary filter-btn">Bestsellers</button>
    </div>

    <div class="row g-4">
        <?php
        // Fetch dynamic products from the database for Aahar
        $query = "SELECT * FROM products WHERE service_type = 'aahar'";
        $result = $conn->query($query);

        if ($result && $result->num_rows > 0): 
            while ($f = $result->fetch_assoc()): 
                // Image handling: Use DB image, or a stylish fallback food image
                $img_src = (!empty($f['image_path']) && $f['image_path'] != 'uploads/default.png') 
                            ? $f['image_path'] 
                            : 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&q=80'; // Appetizing fallback
        ?>
        <div class="col-md-6 col-lg-4">
            <div class="card food-card h-100 d-flex flex-column">
                
                <div class="img-container">
                    <div class="food-badge text-success">
                        <i class="bi bi-star-fill text-warning"></i> 4.5
                    </div>
                    <img src="<?php echo htmlspecialchars($img_src); ?>" class="product-img" alt="<?php echo htmlspecialchars($f['name']); ?>">
                </div>
                
                <div class="card-body p-4 d-flex flex-column">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h5 class="fw-bold mb-0 text-dark"><?php echo htmlspecialchars($f['name']); ?></h5>
                        
                        <form action="add_to_cart.php" method="POST" class="m-0">
                            <input type="hidden" name="product_id" value="<?php echo $f['id']; ?>">
                            <input type="hidden" name="name" value="<?php echo htmlspecialchars($f['name']); ?>">
                            <input type="hidden" name="price" value="<?php echo $f['price']; ?>">
                            <button type="submit" class="btn btn-add shadow-sm">+ Add</button>
                        </form>
                    </div>
                    
                    <p class="small text-muted mb-4 flex-grow-1 line-clamp">
                        <?php echo htmlspecialchars($f['description'] ?? 'Freshly prepared and delivered hot to your doorstep.'); ?>
                    </p>
                    
                    <div class="d-flex align-items-center justify-content-between mt-auto pt-3 border-top">
                        <span class="fw-bold fs-4" style="color: #ee0979;">₹<?php echo number_format($f['price'], 2); ?></span>
                        <small class="text-muted"><i class="bi bi-clock-history"></i> 30-45 min</small>
                    </div>
                </div>
            </div>
        </div>
        <?php 
            endwhile; 
        else: 
        ?>
            <div class="col-12 text-center py-5 mt-4">
                <div class="display-1 text-muted opacity-25 mb-3">🍽️</div>
                <h4 class="fw-bold text-dark">No dishes available right now</h4>
                <p class="text-muted">Head over to the Admin Hub to add some delicious food items!</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>