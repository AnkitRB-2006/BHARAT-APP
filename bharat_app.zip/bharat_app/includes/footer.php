<footer class="bg-white border-top pt-5 pb-4 mt-5">
    <div class="container">
        <div class="row g-4 mb-4">
            <div class="col-lg-4">
                <h4 class="fw-bold text-orange mb-3">B Bharat</h4>
                <p class="text-muted small mb-4">India's Super App - Your one-stop solution for rides, food, groceries, and more.</p>
                <div class="small">
                    <p class="mb-1 text-muted">📞 1800-123-4567</p>
                    <p class="mb-1 text-muted">✉️ help@bharat.app</p>
                    <p class="text-muted">📍 Mumbai, India</p>
                </div>
            </div>
            <div class="col-6 col-md-3 col-lg-2">
                <h6 class="fw-bold mb-3">Services</h6>
                <ul class="list-unstyled small text-muted">
                    <li class="mb-2">Yatra - Rides</li>
                    <li class="mb-2">Aahar - Food</li>
                    <li class="mb-2">Kirana - Grocery</li>
                </ul>
            </div>
            <div class="col-6 col-md-3 col-lg-2">
                <h6 class="fw-bold mb-3">Company</h6>
                <ul class="list-unstyled small text-muted">
                    <li class="mb-2">About Us</li>
                    <li class="mb-2">Careers</li>
                    <li class="mb-2">Blog</li>
                </ul>
            </div>
        </div>
        <div class="border-top pt-4 d-flex justify-content-between align-items-center small text-muted">
            <p class="mb-0">© 2024 Bharat Super App. All rights reserved.</p>
            <div class="d-flex gap-3">
                <a href="#" class="text-muted text-decoration-none">Privacy Policy</a>
                <a href="#" class="text-muted text-decoration-none">Terms of Service</a>
            </div>
        </div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>