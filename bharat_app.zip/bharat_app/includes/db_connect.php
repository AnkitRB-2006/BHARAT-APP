<?php
// Database configuration for XAMPP
$servername = "localhost";
$username = "root";      // Default XAMPP username
$password = "";          // Default XAMPP password (empty)
$dbname = "bharat_app";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8mb4 for Hindi support (Yatra/Aahar labels)
$conn->set_charset("utf8mb4");

/**
 * Note: Use this $conn variable in your pages to perform queries.
 * Example: $result = $conn->query("SELECT * FROM products");
 */
?>