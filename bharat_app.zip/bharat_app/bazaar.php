<?php 
session_start();
include 'db.php'; // Connect to database to fetch live products
include 'includes/header.php'; 
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f4f6f9;
    }

    /* Vibrant Hero Section for Bazaar */
    .bazaar-hero {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 60px 20px;
        border-radius: 0 0 40px 40px;
        margin-top: -20px;
        box-shadow: 0 10px 30px rgba(118, 75, 162, 0.2);
    }

    /* Search Bar Styling */
    .search-bar {
        background: rgba(255, 255, 255, 0.2);
        border: 2px solid rgba(255, 255, 255, 0.5);
        color: white;
        backdrop-filter: blur(10px);
    }
    .search-bar::placeholder { color: rgba(255, 255, 255, 0.8); }
    .search-bar:focus { background: white; color: #333; border-color: white; box-shadow: none; }

    /* Modern Product Cards */
    .product-card {
        border: none;
        border-radius: 20px;
        background: white;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    }
    .product-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(118, 75, 162, 0.15);
    }

    /* Image Styling & Animation */
    .img-container {
        width: 100%;
        height: 220px;
        overflow: hidden;
        position: relative;
        background-color: #f8f9fa;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .product-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }
    .product-card:hover .product-img {
        transform: scale(1.1);
    }

    /* Sidebar Links */
    .list-group-item {
        border: none;
        padding: 12px 20px;
        margin-bottom: 5px;
        border-radius: 10px !important;
        font-weight: 500;
        transition: 0.3s;
    }
    .list-group-item.active {
        background-color: #764ba2;
        color: white;
    }
    .list-group-item:hover:not(.active) {
        background-color: #f0f0f5;
        color: #764ba2;
    }

    /* Custom Add Button */
    .btn-add {
        color: #764ba2;
        border: 2px solid #764ba2;
        border-radius: 20px;
        font-weight: 600;
        padding: 4px 16px;
        background: transparent;
        transition: 0.3s;
    }
    .btn-add:hover {
        background: #764ba2;
        color: white;
        transform: scale(1.05);
    }
</style>

<div class="bazaar-hero mb-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-7">
                <h1 class="fw-bold mb-2 display-5"><i class="bi bi-bag-check-fill"></i> Bazaar</h1>
                <p class="fs-5 opacity-75 mb-0">Shop electronics, fashion, home decor & more.</p>
            </div>
            <div class="col-md-5 mt-4 mt-md-0">
                <div class="input-group">
                    <span class="input-group-text bg-transparent border-0 text-white fs-4 position-absolute" style="z-index: 10; left: 10px; top: 2px;"><i class="bi bi-search"></i></span>
                    <input type="text" class="form-control form-control-lg rounded-pill search-bar ps-5" placeholder="Search smartphones, shoes, watches...">
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mb-5">
    <div class="row g-4">
        
        <div class="col-md-3">
            <div class="bg-white p-3 rounded-4 shadow-sm mb-4">
                <h6 class="fw-bold text-muted mb-3 px-2">CATEGORIES</h6>
                <div class="list-group border-0">
                    <a href="#" class="list-group-item list-group-item-action active"><i class="bi bi-grid-fill me-2"></i> All Products</a>
                    <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-laptop me-2"></i> Electronics</a>
                    <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-smartwatch me-2"></i> Fashion & Accessories</a>
                    <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-house-heart me-2"></i> Home Decor</a>
                </div>
            </div>
        </div>

        <div class="col-md-9">
            <div class="row g-4">
                <?php
                // Fetch dynamic products from the database for Bazaar
                $query = "SELECT * FROM products WHERE service_type = 'bazaar'";
                $result = $conn->query($query);

                if ($result && $result->num_rows > 0): 
                    while ($f = $result->fetch_assoc()): 
                        // Image handling: Use DB image, or a stylish shopping fallback image
                        $img_src = (!empty($f['image_path']) && $f['image_path'] != 'uploads/default.png') 
                                    ? $f['image_path'] 
                                    : 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&q=80'; // Sleek product fallback
                ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card product-card h-100 d-flex flex-column">
                        
                        <div class="img-container">
                            <span class="badge bg-danger position-absolute top-0 start-0 m-3 z-3 shadow-sm">Hot</span>
                            <img src="<?php echo htmlspecialchars($img_src); ?>" class="product-img" alt="<?php echo htmlspecialchars($f['name']); ?>" onerror="this.src='https://via.placeholder.com/400x300?text=No+Image'">
                        </div>
                        
                        <div class="card-body p-4 d-flex flex-column">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h6 class="fw-bold mb-0 text-dark" style="font-size: 1.1rem; line-height: 1.3;"><?php echo htmlspecialchars($f['name']); ?></h6>
                            </div>
                            
                            <p class="small text-muted mb-4 flex-grow-1">
                                <?php echo htmlspecialchars($f['description'] ?? 'Premium quality product available exclusively on Bharat App.'); ?>
                            </p>
                            
                            <div class="d-flex align-items-center justify-content-between mt-auto pt-3 border-top">
                                <div>
                                    <span class="fw-bold fs-5" style="color: #764ba2;">₹<?php echo number_format($f['price'], 2); ?></span>
                                </div>
                                
                                <form action="add_to_cart.php" method="POST" class="m-0">
                                    <input type="hidden" name="product_id" value="<?php echo $f['id']; ?>">
                                    <input type="hidden" name="name" value="<?php echo htmlspecialchars($f['name']); ?>">
                                    <input type="hidden" name="price" value="<?php echo $f['price']; ?>">
                                    <button type="submit" class="btn btn-add shadow-sm">+ Add</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php 
                    endwhile; 
                else: 
                ?>
                    <div class="col-12 text-center py-5 mt-4 bg-white rounded-4 shadow-sm">
                        <div class="display-1 text-muted opacity-25 mb-3">🛍️</div>
                        <h4 class="fw-bold text-dark">Bazaar is currently empty</h4>
                        <p class="text-muted">Head over to the Admin Hub to add some electronics, fashion, or home decor items!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>