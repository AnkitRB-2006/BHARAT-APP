<?php
// db.php
$servername = "localhost";
$username = "root";      
$password = "";          
$dbname = "bharat_app";

// 1. Connect to MySQL (without selecting DB yet to avoid errors if it doesn't exist)
$conn = new mysqli($servername, $username, $password);

// 2. Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 3. Auto-Setup: Create DB if it doesn't exist
$conn->query("CREATE DATABASE IF NOT EXISTS $dbname");
$conn->select_db($dbname);

// 4. Set charset for Hindi/Regional support
$conn->set_charset("utf8mb4");
?>