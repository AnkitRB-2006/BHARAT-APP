<?php
require_once 'admin_auth.php';
include 'db.php';

// --- 1. HANDLE DELETE PRODUCT ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_product'])) {
    $product_id = (int)$_POST['product_id'];
    
    // Optional: Fetch image path to delete the physical file from the server
    $img_query = $conn->query("SELECT image_path FROM products WHERE id = $product_id");
    if ($img_query && $img_query->num_rows > 0) {
        $img_path = $img_query->fetch_assoc()['image_path'];
        if ($img_path && $img_path != 'uploads/default.png' && file_exists($img_path)) {
            unlink($img_path); // Delete the image file
        }
    }
    
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    if ($stmt->execute()) {
        $success_msg = "Product deleted successfully.";
    }
}

// --- 2. HANDLE EDIT PRODUCT ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_product'])) {
    $id = (int)$_POST['product_id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $service_type = $_POST['service_type'];
    
    // Check if a NEW image was uploaded
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == 0) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
        
        $file_extension = pathinfo($_FILES["product_image"]["name"], PATHINFO_EXTENSION);
        $new_file_name = uniqid('img_') . '.' . $file_extension;
        $target_file = $target_dir . $new_file_name;
        
        if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
            // Update WITH new image
            $stmt = $conn->prepare("UPDATE products SET name=?, price=?, service_type=?, image_path=? WHERE id=?");
            $stmt->bind_param("sdssi", $name, $price, $service_type, $target_file, $id);
            $stmt->execute();
            $success_msg = "Product updated successfully with new image.";
        }
    } else {
        // Update WITHOUT changing the existing image
        $stmt = $conn->prepare("UPDATE products SET name=?, price=?, service_type=? WHERE id=?");
        $stmt->bind_param("sdsi", $name, $price, $service_type, $id);
        $stmt->execute();
        $success_msg = "Product updated successfully.";
    }
}

// --- 3. HANDLE SEARCH & FILTER ---
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$filter_service = isset($_GET['service_filter']) ? $conn->real_escape_string($_GET['service_filter']) : '';

$query_str = "SELECT * FROM products WHERE 1=1";

if (!empty($search)) {
    $query_str .= " AND name LIKE '%$search%'";
}
if (!empty($filter_service)) {
    $query_str .= " AND service_type = '$filter_service'";
}

$query_str .= " ORDER BY id DESC";
$products = $conn->query($query_str);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Products - Admin Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; font-family: 'Poppins', sans-serif; }
        .admin-nav { background-color: #002147; padding: 10px 0; }
        .admin-nav .nav-link { color: white !important; font-weight: 500; margin: 0 10px; }
        .admin-nav .active { color: #ff9933 !important; }
        .table-card { background: white; border-radius: 15px; padding: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .prod-thumb { width: 50px; height: 50px; object-fit: cover; border-radius: 8px; }
        .search-bar { max-width: 600px; }
    </style>
</head>
<body>

<nav class="admin-nav shadow-sm mb-5">
    <div class="container d-flex justify-content-between align-items-center">
        <a class="navbar-brand text-white fw-bold" href="index.php">☁️ Bharat App</a>
        <div class="d-flex align-items-center">
            <a class="nav-link" href="admin-dashboard.php">Dashboard</a>
            <a class="nav-link" href="admin-orders.php">Manage Orders</a>
            <a class="nav-link active" href="admin-products.php">Inventory</a>
            <a class="nav-link" href="admin_auth.php?logout=true" style="color: #ff4d4d !important;">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <?php if(isset($success_msg)): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm border-0" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> <?php echo $success_msg; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <h2 class="fw-bold mb-0">Product Inventory</h2>
        <a href="admin-dashboard.php" class="btn btn-outline-dark rounded-pill px-4">+ Add New Product</a>
    </div>

    <div class="card border-0 shadow-sm rounded-4 p-3 mb-4">
        <form method="GET" action="admin-products.php" class="row g-2 align-items-center">
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
                    <input type="text" name="search" class="form-control border-start-0 ps-0" placeholder="Search by product name..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
            </div>
            <div class="col-md-4">
                <select name="service_filter" class="form-select">
                    <option value="">All Services</option>
                    <option value="aahar" <?php if($filter_service == 'aahar') echo 'selected'; ?>>🍲 Aahar</option>
                    <option value="kirana" <?php if($filter_service == 'kirana') echo 'selected'; ?>>🥦 Kirana</option>
                    <option value="bazaar" <?php if($filter_service == 'bazaar') echo 'selected'; ?>>🛍️ Bazaar</option>
                    <option value="uphaar" <?php if($filter_service == 'uphaar') echo 'selected'; ?>>🎀 Uphaar</option>
                    <option value="dawai" <?php if($filter_service == 'dawai') echo 'selected'; ?>>💊 Dawai</option>
                    <option value="seva" <?php if($filter_service == 'seva') echo 'selected'; ?>>🧹 Seva</option>
                </select>
            </div>
            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-primary w-100" style="background-color: #002147; border: none;">Filter</button>
                <?php if(!empty($search) || !empty($filter_service)): ?>
                    <a href="admin-products.php" class="btn btn-light border w-50">Clear</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <div class="table-card">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="fw-bold text-muted m-0">Showing <?php echo $products ? $products->num_rows : 0; ?> results</h6>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle text-nowrap">
                <thead class="table-light">
                    <tr>
                        <th>Image</th>
                        <th>Product Name</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($products && $products->num_rows > 0): ?>
                        <?php while($row = $products->fetch_assoc()): 
                            $img = !empty($row['image_path']) ? $row['image_path'] : 'uploads/default.png';
                        ?>
                        <tr>
                            <td><img src="<?php echo htmlspecialchars($img); ?>" class="prod-thumb shadow-sm" alt="Product" onerror="this.src='https://via.placeholder.com/50'"></td>
                            <td class="fw-bold"><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><span class="badge bg-secondary rounded-pill px-3 bg-opacity-10 text-dark border border-secondary"><?php echo ucfirst($row['service_type']); ?></span></td>
                            <td class="fw-bold text-success">₹<?php echo number_format($row['price'], 2); ?></td>
                            <td class="text-end">
                                <button class="btn btn-sm btn-outline-primary rounded-pill px-3 me-1" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $row['id']; ?>">
                                    <i class="bi bi-pencil-square"></i> Edit
                                </button>
                                
                                <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this product?');">
                                    <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                                    <input type="hidden" name="delete_product" value="1">
                                    <button type="submit" class="btn btn-sm btn-outline-danger rounded-pill px-3">
                                        <i class="bi bi-trash"></i> Delete
                                    </button>
                                </form>
                            </td>
                        </tr>

                        <div class="modal fade" id="editModal<?php echo $row['id']; ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content border-0 rounded-4 shadow-lg">
                                    <div class="modal-header bg-light border-0 rounded-top-4">
                                        <h5 class="modal-title fw-bold">Edit Product</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <form action="admin-products.php" method="POST" enctype="multipart/form-data">
                                        <div class="modal-body p-4">
                                            <input type="hidden" name="edit_product" value="1">
                                            <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                                            
                                            <div class="mb-3">
                                                <label class="form-label fw-bold text-muted small">SERVICE CATEGORY</label>
                                                <select name="service_type" class="form-select" required>
                                                    <option value="aahar" <?php if($row['service_type']=='aahar') echo 'selected'; ?>>🍲 Aahar</option>
                                                    <option value="kirana" <?php if($row['service_type']=='kirana') echo 'selected'; ?>>🥦 Kirana</option>
                                                    <option value="bazaar" <?php if($row['service_type']=='bazaar') echo 'selected'; ?>>🛍️ Bazaar</option>
                                                    <option value="uphaar" <?php if($row['service_type']=='uphaar') echo 'selected'; ?>>🎀 Uphaar</option>
                                                    <option value="dawai" <?php if($row['service_type']=='dawai') echo 'selected'; ?>>💊 Dawai</option>
                                                    <option value="seva" <?php if($row['service_type']=='seva') echo 'selected'; ?>>🧹 Seva</option>
                                                </select>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label fw-bold text-muted small">PRODUCT NAME</label>
                                                <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($row['name']); ?>" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label fw-bold text-muted small">PRICE (₹)</label>
                                                <input type="number" name="price" class="form-control" step="0.01" value="<?php echo $row['price']; ?>" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label fw-bold text-muted small">UPDATE PHOTO (Optional)</label>
                                                <input type="file" name="product_image" class="form-control" accept="image/*">
                                                <small class="text-muted mt-1 d-block">Leave blank to keep the current image.</small>
                                            </div>
                                        </div>
                                        <div class="modal-footer border-0 p-4 pt-0">
                                            <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-primary rounded-pill px-4" style="background-color: #002147; border: none;">Save Changes</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center py-5 text-muted">No products match your search.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>