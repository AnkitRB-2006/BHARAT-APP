<?php 
session_start();
include 'db.php'; // Connect to database to fetch live products
include 'includes/header.php'; 
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f4f6f9;
    }

    /* Fresh Kirana Hero Section */
    .kirana-hero {
        background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        color: white;
        padding: 60px 20px;
        border-radius: 0 0 40px 40px;
        margin-top: -20px;
        box-shadow: 0 10px 30px rgba(17, 153, 142, 0.2);
    }

    /* Search Bar Styling */
    .search-bar {
        background: rgba(255, 255, 255, 0.2);
        border: 2px solid rgba(255, 255, 255, 0.5);
        color: white;
        backdrop-filter: blur(10px);
    }
    .search-bar::placeholder { color: rgba(255, 255, 255, 0.8); }
    .search-bar:focus { background: white; color: #333; border-color: white; box-shadow: none; }

    /* Modern Product Cards */
    .product-card {
        border: none;
        border-radius: 20px;
        background: white;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    }
    .product-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(17, 153, 142, 0.15);
    }

    /* Image Styling & Animation */
    .img-container {
        width: 100%;
        height: 180px;
        overflow: hidden;
        position: relative;
        background-color: #f8f9fa;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .product-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }
    .product-card:hover .product-img {
        transform: scale(1.1);
    }

    /* Sidebar Links */
    .list-group-item {
        border: none;
        padding: 12px 20px;
        margin-bottom: 5px;
        border-radius: 10px !important;
        font-weight: 500;
        transition: 0.3s;
    }
    .list-group-item.active {
        background-color: #11998e;
        color: white;
    }
    .list-group-item:hover:not(.active) {
        background-color: #e6f9f0;
        color: #11998e;
    }

    /* Custom Add Button */
    .btn-add {
        color: #11998e;
        border: 2px solid #11998e;
        border-radius: 20px;
        font-weight: 600;
        padding: 4px 16px;
        background: transparent;
        transition: 0.3s;
    }
    .btn-add:hover {
        background: #11998e;
        color: white;
        transform: scale(1.05);
    }
</style>

<div class="kirana-hero mb-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-7">
                <span class="badge bg-white text-success mb-2 px-3 py-2 rounded-pill fw-bold">⚡ 15 Min Delivery</span>
                <h1 class="fw-bold mb-2 display-5"><i class="bi bi-basket-fill"></i> Kirana</h1>
                <p class="fs-5 opacity-75 mb-0">Fresh groceries and daily essentials at your door.</p>
            </div>
            <div class="col-md-5 mt-4 mt-md-0">
                <div class="input-group">
                    <span class="input-group-text bg-transparent border-0 text-white fs-4 position-absolute" style="z-index: 10; left: 10px; top: 2px;"><i class="bi bi-search"></i></span>
                    <input type="text" class="form-control form-control-lg rounded-pill search-bar ps-5" placeholder="Search rice, milk, vegetables...">
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mb-5">
    <div class="row g-4">
        
        <div class="col-md-3">
            <div class="bg-white p-3 rounded-4 shadow-sm mb-4">
                <h6 class="fw-bold text-muted mb-3 px-2">AISLES</h6>
                <div class="list-group border-0">
                    <a href="#" class="list-group-item list-group-item-action active"><i class="bi bi-grid-fill me-2"></i> All Items</a>
                    <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-flower1 me-2"></i> Grains & Pulses</a>
                    <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-egg-fried me-2"></i> Dairy & Eggs</a>
                    <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-apple me-2"></i> Fresh Vegetables</a>
                    <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-cup-hot me-2"></i> Snacks & Beverages</a>
                </div>
            </div>
        </div>

        <div class="col-md-9">
            <div class="row g-4">
                <?php
                // Fetch dynamic products from the database for Kirana
                $query = "SELECT * FROM products WHERE service_type = 'kirana'";
                $result = $conn->query($query);

                if ($result && $result->num_rows > 0): 
                    while ($f = $result->fetch_assoc()): 
                        // Image handling: Use DB image, or a fresh grocery fallback image
                        $img_src = (!empty($f['image_path']) && $f['image_path'] != 'uploads/default.png') 
                                    ? $f['image_path'] 
                                    : 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=600&q=80'; // Fresh produce fallback
                ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card product-card h-100 d-flex flex-column">
                        
                        <div class="img-container p-2">
                            <img src="<?php echo htmlspecialchars($img_src); ?>" class="product-img rounded-3" alt="<?php echo htmlspecialchars($f['name']); ?>" onerror="this.src='https://via.placeholder.com/400x300?text=No+Image'">
                        </div>
                        
                        <div class="card-body p-3 d-flex flex-column">
                            <div class="d-flex justify-content-between align-items-start mb-1">
                                <h6 class="fw-bold mb-0 text-dark" style="font-size: 1.05rem; line-height: 1.2;"><?php echo htmlspecialchars($f['name']); ?></h6>
                            </div>
                            
                            <p class="small text-muted mb-3 flex-grow-1 line-clamp">
                                <?php echo htmlspecialchars($f['description'] ?? 'Daily fresh groceries.'); ?>
                            </p>
                            
                            <div class="d-flex align-items-center justify-content-between mt-auto pt-2 border-top">
                                <div>
                                    <span class="fw-bold fs-5 text-success">₹<?php echo number_format($f['price'], 2); ?></span>
                                </div>
                                
                                <form action="add_to_cart.php" method="POST" class="m-0">
                                    <input type="hidden" name="product_id" value="<?php echo $f['id']; ?>">
                                    <input type="hidden" name="name" value="<?php echo htmlspecialchars($f['name']); ?>">
                                    <input type="hidden" name="price" value="<?php echo $f['price']; ?>">
                                    <button type="submit" class="btn btn-add shadow-sm">+ Add</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php 
                    endwhile; 
                else: 
                ?>
                    <div class="col-12 text-center py-5 mt-4 bg-white rounded-4 shadow-sm">
                        <div class="display-1 text-muted opacity-25 mb-3">🛒</div>
                        <h4 class="fw-bold text-dark">Aisles are empty!</h4>
                        <p class="text-muted">Head over to the Admin Hub to stock up the Kirana store with fresh items!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>