<?php
require_once 'admin_auth.php';
include 'db.php';

// --- 1. HANDLE FILTERS & SEARCH ---
$filter = $_GET['period'] ?? 'All';
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

$query_str = "SELECT orders.id, orders.total, orders.created_at, orders.status, users.full_name 
              FROM orders 
              LEFT JOIN users ON orders.user_id = users.id 
              WHERE (orders.status = 'Delivered' OR orders.status = 'Shipped')";

// Apply Date Filters
if ($filter == 'Today') {
    $query_str .= " AND DATE(orders.created_at) = CURDATE()";
} elseif ($filter == 'Week') {
    $query_str .= " AND orders.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
} elseif ($filter == 'Month') {
    $query_str .= " AND orders.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
}

// Apply Search
if (!empty($search)) {
    $query_str .= " AND (users.full_name LIKE '%$search%' OR orders.id LIKE '%$search%')";
}

$query_str .= " ORDER BY orders.created_at DESC";
$payments = $conn->query($query_str);

// --- 2. CALCULATE SUMMARY STATS ---
$total_revenue = 0;
$today_revenue = 0;
$transaction_count = $payments->num_rows;

if ($conn) {
    // Total lifetime verified revenue
    $rev_result = $conn->query("SELECT SUM(total) as s FROM orders WHERE status IN ('Delivered', 'Shipped')");
    $total_revenue = $rev_result->fetch_assoc()['s'] ?? 0;

    // Today's revenue
    $today_result = $conn->query("SELECT SUM(total) as s FROM orders WHERE status IN ('Delivered', 'Shipped') AND DATE(created_at) = CURDATE()");
    $today_revenue = $today_result->fetch_assoc()['s'] ?? 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Financial Ledger - Admin Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f4f7f6; font-family: 'Poppins', sans-serif; }
        
        .admin-nav { background: linear-gradient(135deg, #001f3f 0%, #00152a 100%); padding: 15px 0; }
        .admin-nav .nav-link { color: rgba(255, 255, 255, 0.7) !important; font-weight: 500; margin: 0 5px; padding: 8px 16px; border-radius: 8px; transition: 0.3s; }
        .admin-nav .nav-link:hover { color: #ffffff !important; background: rgba(255, 255, 255, 0.1); }
        .admin-nav .active { color: #ff9933 !important; background: rgba(255, 153, 51, 0.1); }

        .table-card { background: white; border-radius: 24px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.02); border: 1px solid #e9ecef; }
        
        .stat-widget { background: white; border-radius: 20px; padding: 20px; border: 1px solid #e9ecef; box-shadow: 0 4px 12px rgba(0,0,0,0.02); }
        
        .period-btn { border-radius: 12px; font-weight: 600; font-size: 0.85rem; transition: 0.3s; }
        .period-btn.active { background-color: #002147 !important; color: white !important; border-color: #002147; }
        
        .txn-id { font-family: 'Courier New', Courier, monospace; font-weight: 700; color: #6c757d; }
    </style>
</head>
<body>

<nav class="admin-nav shadow-sm mb-5">
    <div class="container d-flex justify-content-between align-items-center">
        <a class="navbar-brand text-white fw-bold fs-4" href="index.php"><i class="bi bi-cloud-fill me-2" style="color: #ff9933;"></i>Bharat App</a>
        <div class="d-flex align-items-center">
            <a class="nav-link" href="admin-dashboard.php">Dashboard</a>
            <a class="nav-link" href="admin-orders.php">Manage Orders</a>
            <a class="nav-link" href="admin-products.php">Inventory</a>
            <a class="nav-link active" href="admin-payments.php">Payments</a>
            <a class="nav-link text-danger ms-3" href="admin_auth.php?logout=true" style="background: rgba(220,53,69,0.1);"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </div>
    </div>
</nav>

<div class="container py-4">
    
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-5 gap-3">
        <div>
            <h2 class="fw-bold mb-0 text-dark">Payment Ledger</h2>
            <p class="text-muted mb-0">Track and verify all incoming settlements.</p>
        </div>
        <button onclick="window.print()" class="btn btn-outline-dark rounded-pill px-4 fw-bold shadow-sm">
            <i class="bi bi-download me-2"></i> Export PDF
        </button>
    </div>

    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="stat-widget d-flex align-items-center">
                <div class="bg-success bg-opacity-10 text-success p-3 rounded-4 me-3"><i class="bi bi-bank fs-3"></i></div>
                <div>
                    <small class="text-muted d-block text-uppercase fw-bold" style="font-size: 0.7rem; letter-spacing: 1px;">Lifetime Revenue</small>
                    <h4 class="fw-bold mb-0">₹<?php echo number_format($total_revenue, 2); ?></h4>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-widget d-flex align-items-center border-primary border-opacity-25">
                <div class="bg-primary bg-opacity-10 text-primary p-3 rounded-4 me-3"><i class="bi bi-lightning-charge fs-3"></i></div>
                <div>
                    <small class="text-muted d-block text-uppercase fw-bold" style="font-size: 0.7rem; letter-spacing: 1px;">Today's Settlement</small>
                    <h4 class="fw-bold mb-0 text-primary">₹<?php echo number_format($today_revenue, 2); ?></h4>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-widget d-flex align-items-center">
                <div class="bg-info bg-opacity-10 text-info p-3 rounded-4 me-3"><i class="bi bi-receipt fs-3"></i></div>
                <div>
                    <small class="text-muted d-block text-uppercase fw-bold" style="font-size: 0.7rem; letter-spacing: 1px;">Successful TXNs</small>
                    <h4 class="fw-bold mb-0"><?php echo number_format($transaction_count); ?></h4>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 p-3 mb-4">
        <form method="GET" class="row g-3 align-items-center">
            <div class="col-md-4 d-flex gap-2">
                <a href="admin-payments.php?period=All" class="btn btn-light border flex-grow-1 period-btn <?php echo ($filter == 'All') ? 'active' : ''; ?>">All</a>
                <a href="admin-payments.php?period=Today" class="btn btn-light border flex-grow-1 period-btn <?php echo ($filter == 'Today') ? 'active' : ''; ?>">Today</a>
                <a href="admin-payments.php?period=Week" class="btn btn-light border flex-grow-1 period-btn <?php echo ($filter == 'Week') ? 'active' : ''; ?>">Weekly</a>
            </div>
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0 text-muted"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" class="form-control border-start-0 ps-0" placeholder="Search by Transaction ID or Customer Name..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-dark w-100 rounded-3 fw-bold">Filter</button>
            </div>
        </form>
    </div>

    <div class="table-card">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="text-muted small text-uppercase bg-light">
                    <tr>
                        <th class="ps-3 py-3 border-0 rounded-start">Transaction ID</th>
                        <th class="py-3 border-0">Timestamp</th>
                        <th class="py-3 border-0">Customer</th>
                        <th class="py-3 border-0">Method</th>
                        <th class="py-3 border-0 text-end pe-3 rounded-end">Amount Settled</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($payments && $payments->num_rows > 0): ?>
                        <?php while($row = $payments->fetch_assoc()): ?>
                        <tr>
                            <td class="ps-3">
                                <span class="txn-id">TXN-<?php echo $row['id'] . "501" . substr(time(), -3); ?></span>
                            </td>
                            <td>
                                <div class="fw-medium text-dark"><?php echo date('d M, Y', strtotime($row['created_at'])); ?></div>
                                <div class="text-muted small"><?php echo date('h:i A', strtotime($row['created_at'])); ?></div>
                            </td>
                            <td>
                                <div class="fw-bold text-dark"><?php echo htmlspecialchars($row['full_name'] ?? 'Guest User'); ?></div>
                                <span class="badge bg-success bg-opacity-10 text-success border border-success rounded-pill" style="font-size: 0.65rem;">VERIFIED PAID</span>
                            </td>
                            <td>
                                <span class="text-muted small"><i class="bi bi-credit-card me-1"></i> Online / Wallet</span>
                            </td>
                            <td class="text-end pe-3 fw-bold text-dark fs-5">
                                ₹<?php echo number_format($row['total'], 2); ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center py-5">
                                <div class="display-1 text-muted opacity-25 mb-3"><i class="bi bi-cash-stack"></i></div>
                                <h5 class="fw-bold text-dark">No transactions recorded</h5>
                                <p class="text-muted small">Completed payments will appear here automatically.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>