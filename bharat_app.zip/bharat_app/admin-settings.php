<?php
// 1. Start the session first to access $_SESSION data
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. Gatekeeper: If no admin_id is found, redirect to login
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php"); // Ensure this matches your login filename
    exit();
}

require_once 'admin_auth.php';
include 'db.php';

$admin_id = $_SESSION['admin_id'];

// --- 3. HANDLE PROFILE UPDATE ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $new_name = $conn->real_escape_string($_POST['admin_name']);
    $new_email = $conn->real_escape_string($_POST['admin_email']);

    $stmt = $conn->prepare("UPDATE admins SET full_name = ?, email = ? WHERE id = ?");
    $stmt->bind_param("ssi", $new_name, $new_email, $admin_id);
    
    if ($stmt->execute()) {
        $_SESSION['admin_name'] = $new_name; 
        $success_msg = "Profile details updated successfully!";
    }
}

// --- 4. HANDLE PASSWORD CHANGE ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    $current_pass = $_POST['current_password'];
    $new_pass = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];

    // Fetch current hashed password
    $res = $conn->query("SELECT password FROM admins WHERE id = $admin_id");
    $admin = $res->fetch_assoc();

    if (password_verify($current_pass, $admin['password'])) {
        if ($new_pass === $confirm_pass) {
            $hashed_pass = password_hash($new_pass, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE admins SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $hashed_pass, $admin_id);
            $stmt->execute();
            $success_msg = "Password changed successfully!";
        } else {
            $error_msg = "New passwords do not match.";
        }
    } else {
        $error_msg = "Current password is incorrect.";
    }
}

// --- 5. SECURELY FETCH CURRENT DATA ---
$admin_data_query = $conn->query("SELECT * FROM admins WHERE id = $admin_id");
$admin_data = $admin_data_query->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Settings - Bharat App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f4f7f6; font-family: 'Poppins', sans-serif; }
        .admin-nav { background: linear-gradient(135deg, #001f3f 0%, #00152a 100%); padding: 15px 0; }
        .admin-nav .nav-link { color: rgba(255, 255, 255, 0.7) !important; font-weight: 500; margin: 0 5px; }
        .admin-nav .active { color: #ff9933 !important; }
        
        .settings-card { background: white; border-radius: 20px; border: 1px solid #e9ecef; box-shadow: 0 4px 15px rgba(0,0,0,0.02); }
        .form-label { font-weight: 600; color: #495057; font-size: 0.85rem; text-transform: uppercase; }
        .form-control { border-radius: 10px; padding: 12px; background: #fcfcfc; }
        .form-control:focus { border-color: #ff9933; box-shadow: 0 0 0 3px rgba(255, 153, 51, 0.1); }
        
        /* Pills Styling */
        .nav-pills .nav-link { border-radius: 12px; font-weight: 500; color: #6c757d; transition: 0.3s; }
        .nav-pills .nav-link.active { background-color: #002147; color: white; }
    </style>
</head>
<body>

<nav class="admin-nav shadow-sm mb-5">
    <div class="container d-flex justify-content-between align-items-center">
        <a class="navbar-brand text-white fw-bold fs-4" href="index.php"><i class="bi bi-cloud-fill me-2" style="color: #ff9933;"></i>Bharat App</a>
        <div class="d-flex align-items-center">
            <a class="nav-link" href="admin-dashboard.php">Dashboard</a>
            <a class="nav-link" href="admin-orders.php">Orders</a>
            <a class="nav-link active" href="admin-settings.php">Settings</a>
            <a class="nav-link text-danger ms-3" href="admin_auth.php?logout=true"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="mb-4">
        <h2 class="fw-bold mb-1">System Settings</h2>
        <p class="text-muted">Manage your administrative credentials and app configuration.</p>
    </div>

    <?php if(isset($success_msg)): ?>
        <div class="alert alert-success border-0 shadow-sm rounded-3 mb-4"><i class="bi bi-check-circle-fill me-2"></i> <?php echo $success_msg; ?></div>
    <?php endif; ?>
    <?php if(isset($error_msg)): ?>
        <div class="alert alert-danger border-0 shadow-sm rounded-3 mb-4"><i class="bi bi-exclamation-circle-fill me-2"></i> <?php echo $error_msg; ?></div>
    <?php endif; ?>

    <div class="row g-4">
        <div class="col-md-3">
            <div class="settings-card p-3">
                <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <button class="nav-link active text-start mb-2" data-bs-toggle="pill" data-bs-target="#profile" type="button"><i class="bi bi-person-circle me-2"></i> Admin Profile</button>
                    <button class="nav-link text-start mb-2" data-bs-toggle="pill" data-bs-target="#security" type="button"><i class="bi bi-shield-lock me-2"></i> Security</button>
                    <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#app" type="button"><i class="bi bi-gear-wide-connected me-2"></i> App Config</button>
                </div>
            </div>
        </div>

        <div class="col-md-9">
            <div class="tab-content">
                
                <div class="tab-pane fade show active" id="profile">
                    <div class="settings-card p-4 p-md-5">
                        <h5 class="fw-bold mb-4">Edit Profile</h5>
                        <form method="POST">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Full Name</label>
                                    <input type="text" name="admin_name" class="form-control" value="<?php echo htmlspecialchars($admin_data['full_name'] ?? ''); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Email Address</label>
                                    <input type="email" name="admin_email" class="form-control" value="<?php echo htmlspecialchars($admin_data['email'] ?? ''); ?>" required>
                                </div>
                                <div class="col-12 mt-4">
                                    <button type="submit" name="update_profile" class="btn btn-dark px-4 rounded-pill">Update Profile</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="tab-pane fade" id="security">
                    <div class="settings-card p-4 p-md-5">
                        <h5 class="fw-bold mb-4">Change Password</h5>
                        <form method="POST">
                            <div class="row g-3" style="max-width: 500px;">
                                <div class="col-12">
                                    <label class="form-label">Current Password</label>
                                    <input type="password" name="current_password" class="form-control" required>
                                </div>
                                <div class="col-12">
                                    <label class="form-label">New Password</label>
                                    <input type="password" name="new_password" class="form-control" required>
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Confirm New Password</label>
                                    <input type="password" name="confirm_password" class="form-control" required>
                                </div>
                                <div class="col-12 mt-4">
                                    <button type="submit" name="change_password" class="btn btn-primary px-4 rounded-pill" style="background-color: #002147; border: none;">Update Password</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="tab-pane fade" id="app">
                    <div class="settings-card p-4 p-md-5 text-center">
                        <i class="bi bi-cone-striped display-1 text-muted opacity-25"></i>
                        <h5 class="fw-bold mt-3">Platform Configuration</h5>
                        <p class="text-muted">Global settings like Maintenance Mode and Delivery Fees will be available here soon.</p>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>