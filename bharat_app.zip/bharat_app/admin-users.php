<?php
require_once 'admin_auth.php';
include 'db.php';

// --- 1. HANDLE DELETE USER ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_user'])) {
    $user_id = (int)$_POST['user_id'];
    
    // Check if user has active orders before deleting (Optional safety)
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        $success_msg = "User account has been permanently removed.";
    }
}

// --- 2. HANDLE SEARCH ---
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

$query_str = "SELECT * FROM users WHERE 1=1";
if (!empty($search)) {
    $query_str .= " AND (full_name LIKE '%$search%' OR email LIKE '%$search%')";
}
$query_str .= " ORDER BY created_at DESC";

$users = $conn->query($query_str);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Management - Admin Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f4f7f6; font-family: 'Poppins', sans-serif; }
        
        /* Premium Navbar */
        .admin-nav { background: linear-gradient(135deg, #001f3f 0%, #00152a 100%); padding: 15px 0; }
        .admin-nav .nav-link { color: rgba(255, 255, 255, 0.7) !important; font-weight: 500; margin: 0 5px; padding: 8px 16px; border-radius: 8px; transition: 0.3s; }
        .admin-nav .nav-link:hover { color: #ffffff !important; background: rgba(255, 255, 255, 0.1); }
        .admin-nav .active { color: #ff9933 !important; background: rgba(255, 153, 51, 0.1); }

        /* Modern Table Styling */
        .table-card { background: white; border-radius: 24px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.02); border: 1px solid #e9ecef; }
        .table thead th { background-color: #f8f9fa; border: none; padding: 15px; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 1px; color: #6c757d; }
        .table tbody td { padding: 20px 15px; border-bottom: 1px solid #f1f1f1; }
        
        /* Avatar UI */
        .user-avatar {
            width: 45px; height: 45px;
            background: #e3f2fd; color: #0d6efd;
            border-radius: 12px; display: flex;
            align-items: center; justify-content: center;
            font-weight: 700; font-size: 1.2rem;
        }

        .search-container {
            background: white; border-radius: 16px;
            padding: 10px 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.03);
            border: 1px solid #e9ecef;
        }
        .form-control:focus { border-color: #ff9933; box-shadow: 0 0 0 0.25rem rgba(255, 153, 51, 0.15); }
    </style>
</head>
<body>

<nav class="admin-nav shadow-sm mb-5">
    <div class="container d-flex justify-content-between align-items-center">
        <a class="navbar-brand text-white fw-bold fs-4" href="index.php"><i class="bi bi-cloud-fill me-2" style="color: #ff9933;"></i>Bharat App</a>
        <div class="d-flex align-items-center">
            <a class="nav-link" href="admin-dashboard.php">Dashboard</a>
            <a class="nav-link" href="admin-orders.php">Manage Orders</a>
            <a class="nav-link active" href="admin-users.php">Users</a>
            <a class="nav-link text-danger ms-3" href="admin_auth.php?logout=true" style="background: rgba(220,53,69,0.1);"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </div>
    </div>
</nav>

<div class="container py-4">
    
    <?php if(isset($success_msg)): ?>
        <div class="alert alert-success alert-dismissible fade show border-0 rounded-3 shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> <?php echo $success_msg; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row align-items-center mb-5">
        <div class="col-md-6">
            <h2 class="fw-bold mb-0 text-dark">Customer Profiles</h2>
            <p class="text-muted mb-0">Total Registered Members: <strong><?php echo $users ? $users->num_rows : 0; ?></strong></p>
        </div>
        <div class="col-md-6 mt-3 mt-md-0">
            <form method="GET" class="search-container d-flex align-items-center">
                <i class="bi bi-search text-muted me-2"></i>
                <input type="text" name="search" class="form-control border-0 bg-transparent" placeholder="Search by name or email..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit" class="btn btn-dark rounded-pill px-4 ms-2">Filter</button>
            </form>
        </div>
    </div>

    <div class="table-card">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>Customer</th>
                        <th>Email Address</th>
                        <th>Joined Date</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($users && $users->num_rows > 0): ?>
                        <?php while($row = $users->fetch_assoc()): 
                            $initial = strtoupper(substr($row['full_name'], 0, 1));
                            $is_new = (strtotime($row['created_at']) > strtotime('-24 hours'));
                        ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="user-avatar me-3 shadow-sm"><?php echo $initial; ?></div>
                                    <div>
                                        <div class="fw-bold text-dark">
                                            <?php echo htmlspecialchars($row['full_name']); ?>
                                            <?php if($is_new): ?>
                                                <span class="badge bg-success ms-2 rounded-pill" style="font-size: 0.6rem;">NEW</span>
                                            <?php endif; ?>
                                        </div>
                                        <small class="text-muted">ID: #<?php echo sprintf('%05d', $row['id']); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td class="text-secondary">
                                <i class="bi bi-envelope-at me-2"></i><?php echo htmlspecialchars($row['email']); ?>
                            </td>
                            <td>
                                <div class="text-dark fw-medium"><?php echo date('M d, Y', strtotime($row['created_at'])); ?></div>
                                <small class="text-muted"><?php echo date('h:i A', strtotime($row['created_at'])); ?></small>
                            </td>
                            <td class="text-end">
                                <div class="dropdown">
                                    <button class="btn btn-light btn-sm rounded-circle" data-bs-toggle="dropdown"><i class="bi bi-three-dots-vertical"></i></button>
                                    <ul class="dropdown-menu dropdown-menu-end border-0 shadow-lg p-2 rounded-3">
                                        <li><a class="dropdown-item rounded-2" href="mailto:<?php echo $row['email']; ?>"><i class="bi bi-send me-2"></i> Send Email</a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li>
                                            <form method="POST" onsubmit="return confirm('Are you sure you want to delete this user? This action cannot be undone.');">
                                                <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
                                                <input type="hidden" name="delete_user" value="1">
                                                <button type="submit" class="dropdown-item text-danger rounded-2"><i class="bi bi-trash3 me-2"></i> Remove Account</button>
                                            </form>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="4" class="text-center py-5 text-muted">No customers found matching your criteria.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>