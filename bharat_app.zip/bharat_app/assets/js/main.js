document.addEventListener('DOMContentLoaded', () => {
    
    // 1. Yatra Live Fare Estimator
    const rideOptions = document.querySelectorAll('.ride-option');
    const fareDisplay = document.getElementById('estimated-fare');

    if (rideOptions && fareDisplay) {
        rideOptions.forEach(option => {
            option.addEventListener('click', () => {
                const fare = option.getAttribute('data-fare');
                // Remove active class from others
                rideOptions.forEach(opt => opt.classList.remove('active-ride'));
                option.classList.add('active-ride');
                
                // Animate fare update
                fareDisplay.style.opacity = '0';
                setTimeout(() => {
                    fareDisplay.innerText = `₹${fare}`;
                    fareDisplay.style.opacity = '1';
                }, 200);
            });
        });
    }

    // 2. Bharat Plus Trial Simulation
    const trialBtn = document.getElementById('start-trial-btn');
    if (trialBtn) {
        trialBtn.addEventListener('click', () => {
            trialBtn.innerText = "Activating...";
            trialBtn.disabled = true;
            
            setTimeout(() => {
                alert("Welcome to Bharat Plus! Your 14-day free trial is now active.");
                window.location.reload();
            }, 1500);
        });
    }
});