<?php
session_start();

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) { 
    header("Location: auth.php"); 
    exit(); 
}

include 'db.php'; 

$user_id = $_SESSION['user_id'];
$userName = $_SESSION['full_name'] ?? "User"; 
$userEmail = $_SESSION['email'] ?? "member@bharatapp.com";

// Fetch all orders for this user
$orders = $conn->query("SELECT * FROM orders WHERE user_id='$user_id' ORDER BY created_at DESC");

// Calculate total spent
$total_spent = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order_History_BharatApp</title>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@300;400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Merriweather', serif;
            color: #333;
            background: #fff;
            margin: 0;
            padding: 40px;
            font-size: 14px;
        }
        
        /* Container for the document */
        .document-container {
            max-width: 800px;
            margin: 0 auto;
        }

        /* Header Styling */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-bottom: 2px solid #333;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .brand-name {
            font-size: 28px;
            font-weight: 700;
            margin: 0;
            color: #000;
        }
        .document-title {
            font-size: 20px;
            color: #555;
            margin: 5px 0 0 0;
        }
        .date-info {
            text-align: right;
            font-size: 12px;
            color: #666;
        }

        /* User Info Section */
        .user-info {
            margin-bottom: 40px;
        }
        .user-info h3 {
            margin: 0 0 5px 0;
            font-size: 16px;
        }
        .user-info p {
            margin: 0;
            color: #555;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f8f8f8;
            font-weight: 700;
            color: #000;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 1px;
        }
        .text-right {
            text-align: right;
        }
        .status-badge {
            font-size: 12px;
            font-weight: bold;
            padding: 4px 8px;
            border-radius: 4px;
            border: 1px solid #ddd;
        }

        /* Footer Summary */
        .summary-box {
            width: 300px;
            margin-left: auto;
            border-top: 2px solid #333;
            padding-top: 10px;
        }
        .summary-row {
            display: flex;
            justify-content: space-between;
            font-size: 16px;
            font-weight: 700;
        }

        /* Footer */
        .footer {
            margin-top: 60px;
            text-align: center;
            font-size: 12px;
            color: #888;
            border-top: 1px solid #ddd;
            padding-top: 20px;
        }

        /* Print Specific Styles */
        @media print {
            body { padding: 0; }
            .no-print { display: none !important; }
        }

        /* Action Buttons (Hidden during print) */
        .action-buttons {
            text-align: center;
            margin-bottom: 30px;
        }
        .btn {
            padding: 10px 20px;
            background-color: #002147;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-family: sans-serif;
            font-weight: bold;
            cursor: pointer;
            border: none;
        }
        .btn-back {
            background-color: #e0e0e0;
            color: #333;
            margin-right: 10px;
        }
    </style>
</head>
<body>

<div class="document-container">
    
    <div class="action-buttons no-print">
        <a href="account.php" class="btn btn-back">Back to Account</a>
        <button onclick="window.print()" class="btn">Save as PDF / Print</button>
    </div>

    <div class="header">
        <div>
            <h1 class="brand-name">☁️ Bharat App</h1>
            <h2 class="document-title">Order History Statement</h2>
        </div>
        <div class="date-info">
            <p><strong>Generated on:</strong><br><?php echo date('F d, Y - h:i A'); ?></p>
        </div>
    </div>

    <div class="user-info">
        <p style="text-transform: uppercase; font-size: 11px; color: #888; margin-bottom: 5px;">Customer Details</p>
        <h3><?php echo htmlspecialchars($userName); ?></h3>
        <p><?php echo htmlspecialchars($userEmail); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Date & Time</th>
                <th>Status</th>
                <th class="text-right">Amount Paid</th>
            </tr>
        </thead>
        <tbody>
            <?php if($orders && $orders->num_rows > 0): ?>
                <?php while($row = $orders->fetch_assoc()): 
                    $total_spent += $row['total'];
                ?>
                <tr>
                    <td><strong>#BH-<?= sprintf('%05d', $row['id']) ?></strong></td>
                    <td><?= date('M d, Y', strtotime($row['created_at'])) ?><br><span style="color:#888; font-size: 11px;"><?= date('h:i A', strtotime($row['created_at'])) ?></span></td>
                    <td><span class="status-badge"><?= htmlspecialchars($row['status']) ?></span></td>
                    <td class="text-right fw-bold">₹<?= number_format($row['total'], 2) ?></td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" style="text-align: center; padding: 40px; color: #888;">
                        No order history found for this account.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php if($total_spent > 0): ?>
    <div class="summary-box">
        <div class="summary-row">
            <span>Total Lifetime Value:</span>
            <span>₹<?php echo number_format($total_spent, 2); ?></span>
        </div>
    </div>
    <?php endif; ?>

    <div class="footer">
        <p>Thank you for being a valued customer of Bharat App.</p>
        <p>For support, please contact 1800-123-4567 or email support@bharatapp.com</p>
        <p>This is a computer-generated document and does not require a signature.</p>
    </div>

</div>

<script>
    window.onload = function() {
        // Slight delay ensures styles load before the print dialog opens
        setTimeout(function() {
            window.print();
        }, 500);
    };
</script>

</body>
</html>