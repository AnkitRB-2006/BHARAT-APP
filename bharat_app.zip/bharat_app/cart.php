<?php 
session_start();

// Handle item removal from cart
if (isset($_GET['remove']) && isset($_SESSION['cart'][$_GET['remove']])) {
    unset($_SESSION['cart'][$_GET['remove']]);
    header("Location: cart.php");
    exit();
}

include 'includes/header.php';

// Check if user has Bharat Plus
$is_plus = isset($_SESSION['is_plus_member']) && $_SESSION['is_plus_member'] == true;

$subtotal = 0;
$has_uphaar = false;
$cart_empty = empty($_SESSION['cart']);

if(!$cart_empty) {
    foreach($_SESSION['cart'] as $id => $item) {
        $subtotal += $item['price'] * $item['quantity'];
        // Check if any gift items are in the cart (assuming service_type is saved, or we default to true for demo)
        if(isset($item['service_type']) && $item['service_type'] == 'uphaar') {
            $has_uphaar = true;
        }
    }
}

// Delivery fee logic
$delivery_fee = ($is_plus) ? 0 : 40; 
$total = $subtotal + $delivery_fee;
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f4f6f9;
    }

    /* Cart Header */
    .cart-header {
        background: white;
        padding: 40px 0;
        border-bottom: 1px solid #e9ecef;
        margin-top: -20px;
        margin-bottom: 40px;
    }

    /* Cards */
    .cart-card {
        background: white;
        border: none;
        border-radius: 20px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.03);
    }

    /* Item Row */
    .cart-item {
        transition: 0.3s;
        border-bottom: 1px solid #f0f0f5;
    }
    .cart-item:last-child {
        border-bottom: none;
    }
    .cart-item:hover {
        background-color: #f8f9fa;
        border-radius: 12px;
    }

    /* Item Icon/Image placeholder */
    .item-icon {
        width: 60px;
        height: 60px;
        background: #fff4ea;
        color: #ff9933;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
    }

    /* Buttons */
    .btn-checkout {
        background: linear-gradient(45deg, #ff9933, #ff5e62);
        color: white;
        font-weight: 600;
        border: none;
        border-radius: 16px;
        padding: 15px;
        transition: 0.3s;
    }
    .btn-checkout:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(255, 153, 51, 0.3);
        color: white;
    }

    .btn-remove {
        color: #dc3545;
        background: rgba(220, 53, 69, 0.1);
        border: none;
        border-radius: 10px;
        padding: 8px 12px;
        transition: 0.3s;
    }
    .btn-remove:hover {
        background: #dc3545;
        color: white;
    }

    /* Gift Wrap Box */
    .gift-wrap-box {
        background: linear-gradient(135deg, #fff0f5 0%, #ffe4e1 100%);
        border: 1px solid #ffb6c1;
        border-radius: 16px;
        transition: 0.3s;
    }
    .gift-wrap-box:hover {
        box-shadow: 0 5px 15px rgba(255, 182, 193, 0.4);
    }
</style>

<div class="cart-header text-center">
    <div class="container">
        <h2 class="fw-bold mb-0"><i class="bi bi-cart3 text-orange me-2"></i> Your Basket</h2>
    </div>
</div>

<div class="container pb-5">
    
    <?php if($cart_empty): ?>
        <div class="row justify-content-center text-center py-5">
            <div class="col-md-6">
                <div class="display-1 text-muted opacity-25 mb-4">🛒</div>
                <h3 class="fw-bold text-dark">Your basket is empty</h3>
                <p class="text-muted mb-4">Looks like you haven't added anything yet. Explore our services to find what you need!</p>
                <div class="d-flex justify-content-center gap-3">
                    <a href="aahar.php" class="btn btn-outline-dark rounded-pill px-4">Order Food</a>
                    <a href="bazaar.php" class="btn btn-outline-dark rounded-pill px-4">Shop Bazaar</a>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="row g-4">
            
            <div class="col-lg-8">
                <div class="cart-card p-4 mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-4 pb-3 border-bottom">
                        <h5 class="fw-bold mb-0">Items to checkout</h5>
                        <span class="badge bg-light text-dark border"><?php echo count($_SESSION['cart']); ?> Items</span>
                    </div>

                    <div class="cart-items-list">
                        <?php foreach($_SESSION['cart'] as $id => $item): ?>
                        <div class="cart-item d-flex align-items-center py-3 px-2 mb-2">
                            <div class="item-icon me-3">
                                <i class="bi bi-box-seam"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h6 class="fw-bold mb-1 text-dark"><?php echo htmlspecialchars($item['name']); ?></h6>
                                <div class="text-muted small">
                                    ₹<?php echo number_format($item['price'], 2); ?> × <?php echo $item['quantity']; ?>
                                </div>
                            </div>
                            <div class="text-end me-4">
                                <span class="fw-bold fs-5 text-dark">₹<?php echo number_format($item['price'] * $item['quantity'], 2); ?></span>
                            </div>
                            <div>
                                <a href="cart.php?remove=<?php echo $id; ?>" class="btn btn-remove shadow-sm" title="Remove item">
                                    <i class="bi bi-trash3-fill"></i>
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <?php if($has_uphaar): ?>
                <div class="gift-wrap-box p-4 d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center gap-3">
                        <div class="fs-1">🎀</div>
                        <div>
                            <div class="form-check form-switch fs-5">
                                <input class="form-check-input" type="checkbox" id="giftWrapToggle" onchange="updateTotal()">
                                <label class="form-check-label fw-bold ms-2" for="giftWrapToggle" style="color: #D81B60;">
                                    Add Premium Gift Wrapping
                                </label>
                            </div>
                            <small class="text-muted d-block mt-1 ms-5">Make your Uphaar extra special with a personalized box.</small>
                        </div>
                    </div>
                    <div class="text-end">
                        <span class="fw-bold fs-5 <?php echo $is_plus ? 'text-success' : 'text-dark'; ?>">
                            <?php echo $is_plus ? 'FREE' : '₹20'; ?>
                        </span>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="col-lg-4">
                <div class="cart-card p-4 sticky-top" style="top: 100px;">
                    <h5 class="fw-bold mb-4">Order Summary</h5>
                    
                    <div class="d-flex justify-content-between mb-3 text-muted">
                        <span>Item Subtotal</span>
                        <span class="fw-medium text-dark">₹<?php echo number_format($subtotal, 2); ?></span>
                    </div>
                    
                    <div class="d-flex justify-content-between mb-3">
                        <span class="text-muted">Delivery Fee</span>
                        <span class="<?php echo $is_plus ? 'text-success fw-bold' : 'fw-medium text-dark'; ?>">
                            <?php echo $is_plus ? 'FREE (Plus)' : '₹40.00'; ?>
                        </span>
                    </div>

                    <div class="d-flex justify-content-between mb-3 d-none" id="giftWrapRow">
                        <span class="text-muted">Gift Wrapping</span>
                        <span class="<?php echo $is_plus ? 'text-success fw-bold' : 'fw-medium text-dark'; ?>">
                            <?php echo $is_plus ? 'FREE' : '₹20.00'; ?>
                        </span>
                    </div>

                    <hr class="border-secondary opacity-25 my-4">
                    
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <span class="fw-bold fs-5 text-dark">Total Amount</span>
                        <span class="fw-bold fs-3 text-dark" id="finalTotal">₹<?php echo number_format($total, 2); ?></span>
                    </div>

                    <form action="success.php" method="POST">
                        <button type="submit" class="btn btn-checkout w-100 fs-5 d-flex justify-content-center align-items-center gap-2">
                            Proceed to Pay <i class="bi bi-arrow-right-circle-fill"></i>
                        </button>
                    </form>

                    <?php if(!$is_plus): ?>
                        <div class="mt-4 p-3 bg-warning bg-opacity-10 border border-warning border-opacity-25 rounded-3 text-center">
                            <i class="bi bi-star-fill text-warning mb-2 d-block fs-4"></i>
                            <span class="small fw-medium text-dark">Save ₹40 on this delivery with Bharat Plus!</span>
                            <a href="plus.php" class="small fw-bold text-orange d-block mt-1 text-decoration-none">Explore Membership →</a>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<script>
    // Simple script to update total if Gift Wrap is toggled
    const isPlus = <?php echo $is_plus ? 'true' : 'false'; ?>;
    let baseTotal = <?php echo $total; ?>;
    
    function updateTotal() {
        const toggle = document.getElementById('giftWrapToggle');
        const wrapRow = document.getElementById('giftWrapRow');
        const finalTotalDisplay = document.getElementById('finalTotal');
        
        let newTotal = baseTotal;
        
        if (toggle.checked) {
            wrapRow.classList.remove('d-none');
            if (!isPlus) {
                newTotal += 20; // Add 20 if not a plus member
            }
        } else {
            wrapRow.classList.add('d-none');
        }
        
        // Format to 2 decimal places
        finalTotalDisplay.innerText = '₹' + newTotal.toFixed(2);
    }
</script>

<?php include 'includes/footer.php'; ?>