<?php
session_start();
// Redirect to auth.php if no user session is found
if (!isset($_SESSION['user_id'])) { 
    header("Location: auth.php"); 
    exit(); 
}

include 'db.php'; // Centralized database connection
include 'includes/header.php'; // Reusable navigation bar

$user_id = $_SESSION['user_id'];
$userName = $_SESSION['full_name'] ?? "User"; 
$userEmail = $_SESSION['email'] ?? "member@bharatapp.com";
$isPlusMember = isset($_SESSION['is_plus_member']) && $_SESSION['is_plus_member'] == true;

// Fetch the 5 most recent orders for this user
$orders = $conn->query("SELECT * FROM orders WHERE user_id='$user_id' ORDER BY created_at DESC LIMIT 5");
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f4f6f9;
    }

    /* Profile Sidebar */
    .profile-card {
        background: white;
        border-radius: 20px;
        border: none;
        box-shadow: 0 4px 15px rgba(0,0,0,0.03);
    }
    
    .avatar-circle {
        width: 90px;
        height: 90px;
        background: linear-gradient(135deg, #ff9933 0%, #ff5e62 100%);
        color: white;
        font-size: 2.5rem;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        margin: 0 auto;
        box-shadow: 0 8px 15px rgba(255, 153, 51, 0.3);
    }

    /* Sidebar Navigation */
    .profile-nav .list-group-item {
        border: none;
        padding: 12px 20px;
        margin-bottom: 8px;
        border-radius: 12px !important;
        font-weight: 500;
        transition: 0.3s;
        color: #495057;
    }
    .profile-nav .list-group-item.active {
        background-color: #fff4ea;
        color: #ff9933;
    }
    .profile-nav .list-group-item:hover:not(.active) {
        background-color: #f8f9fa;
        color: #ff9933;
    }
    .profile-nav .list-group-item.text-danger:hover {
        background-color: #fff0f0;
        color: #dc3545 !important;
    }

    /* Service Cards */
    .service-card { 
        transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); 
        border-radius: 16px;
        border: none;
        box-shadow: 0 4px 15px rgba(0,0,0,0.02);
    }
    .service-card:hover { 
        transform: translateY(-8px); 
        box-shadow: 0 15px 30px rgba(0,0,0,0.08); 
    }
    .service-icon-box {
        width: 60px;
        height: 60px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.8rem;
        margin: 0 auto 15px;
    }

    /* Order Table */
    .table-card {
        background: white;
        border-radius: 20px;
        border: none;
        box-shadow: 0 4px 15px rgba(0,0,0,0.03);
        padding: 25px;
    }
    .table > :not(caption) > * > * {
        padding: 1rem 0.5rem;
        border-bottom-color: #f0f0f5;
    }
</style>

<div class="container py-5 mt-3">
    <div class="row g-4">
        
        <div class="col-md-4 col-lg-3">
            <div class="profile-card p-4 text-center mb-4">
                <div class="avatar-circle mb-3">
                    <?php echo strtoupper(substr($userName, 0, 1)); ?>
                </div>
                <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($userName); ?></h5>
                <p class="text-muted small mb-3"><?php echo htmlspecialchars($userEmail); ?></p>
                
                <?php if($isPlusMember): ?>
                    <div class="bg-dark text-white rounded-pill d-inline-block px-3 py-1 mb-3 shadow-sm border border-secondary">
                        <i class="bi bi-star-fill text-warning me-1 small"></i> <span class="small fw-bold">Plus Member</span>
                    </div>
                <?php else: ?>
                    <a href="plus.php" class="badge bg-warning bg-opacity-10 text-dark border border-warning rounded-pill px-3 py-2 text-decoration-none mb-3 d-inline-block">
                        Upgrade to Plus <i class="bi bi-arrow-right"></i>
                    </a>
                <?php endif; ?>
                
                <hr class="border-secondary opacity-10 my-4">
                
                <div class="list-group profile-nav text-start">
                    <a href="account.php" class="list-group-item active"><i class="bi bi-grid-fill me-2"></i> Dashboard</a>
                    <a href="cart.php" class="list-group-item"><i class="bi bi-cart3 me-2"></i> My Cart</a>
                    <a href="plus.php" class="list-group-item"><i class="bi bi-star me-2"></i> Bharat Plus</a>
                    <a href="auth.php?action=logout" class="list-group-item text-danger mt-2"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
                </div>
            </div>
        </div>

        <div class="col-md-8 col-lg-9">
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold text-dark mb-0">Hello, <?php echo explode(' ', $userName)[0]; ?>! 👋</h3>
            </div>
            
            <h5 class="fw-bold mb-3 text-dark fs-6">EXPLORE BHARAT SERVICES</h5>
            <div class="row g-3 mb-5">
                
                <div class="col-6 col-md-3">
                    <div class="card service-card text-center p-3 h-100">
                        <div class="service-icon-box bg-danger bg-opacity-10 text-danger">🍲</div>
                        <h6 class="fw-bold mb-1">Aahar</h6>
                        <p class="x-small text-muted mb-3" style="font-size: 0.75rem;">Food Delivery</p>
                        <a href="aahar.php" class="btn btn-sm btn-outline-danger w-100 rounded-pill">Order Now</a>
                    </div>
                </div>

                <div class="col-6 col-md-3">
                    <div class="card service-card text-center p-3 h-100">
                        <div class="service-icon-box bg-dark bg-opacity-10 text-dark">🚕</div>
                        <h6 class="fw-bold mb-1">Yatra</h6>
                        <p class="x-small text-muted mb-3" style="font-size: 0.75rem;">Instant Rides</p>
                        <a href="yatra.php" class="btn btn-sm btn-outline-dark w-100 rounded-pill">Book Ride</a>
                    </div>
                </div>

                <div class="col-6 col-md-3">
                    <div class="card service-card text-center p-3 h-100">
                        <div class="service-icon-box bg-primary bg-opacity-10 text-primary" style="color: #764ba2 !important; background-color: #f3e8ff !important;">🛍️</div>
                        <h6 class="fw-bold mb-1">Bazaar</h6>
                        <p class="x-small text-muted mb-3" style="font-size: 0.75rem;">Shop Anything</p>
                        <a href="bazaar.php" class="btn btn-sm w-100 rounded-pill" style="color: #764ba2; border: 1px solid #764ba2;">Shop Now</a>
                    </div>
                </div>

                <div class="col-6 col-md-3">
                    <div class="card service-card text-center p-3 h-100">
                        <div class="service-icon-box text-danger" style="color: #D81B60 !important; background-color: #fce4ec !important;">🎁</div>
                        <h6 class="fw-bold mb-1">Uphaar</h6>
                        <p class="x-small text-muted mb-3" style="font-size: 0.75rem;">Send Gifts</p>
                        <a href="uphaar.php" class="btn btn-sm w-100 rounded-pill" style="color: #D81B60; border: 1px solid #D81B60;">Send Gift</a>
                    </div>
                </div>
            </div>

            <div class="table-card">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="fw-bold mb-0 text-dark">Recent Orders</h5>
                    <a href="order-history-pdf.php" class="btn btn-sm btn-light border rounded-pill px-3 shadow-sm text-dark">
                        <i class="bi bi-file-earmark-pdf text-danger me-1"></i> Download PDF
                    </a>
                </div>
                
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead class="text-muted small text-uppercase bg-light">
                            <tr>
                                <th class="rounded-start ps-3 py-3 border-0">Order ID</th>
                                <th class="border-0 py-3">Status</th>
                                <th class="border-0 py-3">Date</th>
                                <th class="rounded-end border-0 py-3 text-end pe-3">Amount</th>
                            </tr>
                        </thead>
                        <tbody class="small">
                            <?php if($orders && $orders->num_rows > 0): ?>
                                <?php while($row = $orders->fetch_assoc()): 
                                    // Determine badge color dynamically based on real DB status
                                    $status_class = 'bg-warning text-dark'; // Pending default
                                    if ($row['status'] == 'Shipped') $status_class = 'bg-info text-dark';
                                    if ($row['status'] == 'Delivered') $status_class = 'bg-success text-white';
                                ?>
                                <tr>
                                    <td class="ps-3 fw-bold text-secondary">#BH-<?= sprintf('%05d', $row['id']) ?></td>
                                    <td><span class="badge <?= $status_class ?> rounded-pill px-3 py-2 fw-medium"><?= htmlspecialchars($row['status']) ?></span></td>
                                    <td class="text-muted"><?= date('M d, Y • h:i A', strtotime($row['created_at'])) ?></td>
                                    <td class="text-end pe-3 fw-bold fs-6">₹<?= number_format($row['total'], 2) ?></td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center py-5">
                                        <div class="text-muted mb-2 fs-1 opacity-50">🛒</div>
                                        <h6 class="fw-bold text-dark">No orders yet</h6>
                                        <p class="text-muted small">When you place orders, they will appear here.</p>
                                        <a href="bazaar.php" class="btn btn-sm rounded-pill px-4 mt-2" style="background-color: #ff9933; color: white;">Start Shopping</a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>