<?php
session_start();

// --- 1. BACKEND LOGIC (Database & Auth) ---
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "bharat_app"; 

mysqli_report(MYSQLI_REPORT_OFF);
$conn = new mysqli($servername, $db_username, $db_password);

$conn->query("CREATE DATABASE IF NOT EXISTS $dbname");
$conn->select_db($dbname);

$conn->query("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    header("Location: auth.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    ob_clean();
    header('Content-Type: application/json');
    $response = ["status" => "error", "message" => "Unknown error"];

    try {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (isset($_POST['register'])) {
            $full_name = trim($_POST['full_name'] ?? '');
            
            if (empty($full_name) || empty($email) || empty($password)) throw new Exception("All fields are required.");
            if (!preg_match("/^[a-zA-Z\s]+$/", $full_name)) throw new Exception("Full name must contain only letters and spaces.");
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new Exception("Invalid email format.");
            if (strlen($password) < 6) throw new Exception("Password must be at least 6 characters long.");

            $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $check->bind_param("s", $email);
            $check->execute();
            if ($check->get_result()->num_rows > 0) throw new Exception("Email already exists!");

            $hashed = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $full_name, $email, $hashed);
            
            if ($stmt->execute()) {
                $response = ["status" => "success", "message" => "Account created! Please sign in."];
            }
        } 
        elseif (isset($_POST['login'])) {
            $stmt = $conn->prepare("SELECT id, full_name, password FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($user = $result->fetch_assoc()) {
                if (password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['email'] = $email;
                    $response = ["status" => "success", "redirect" => "account.php"];
                } else {
                    throw new Exception("Incorrect password.");
                }
            } else {
                throw new Exception("User not found.");
            }
        }
    } catch (Exception $e) {
        $response = ["status" => "error", "message" => $e->getMessage()];
    }
    echo json_encode($response);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Bharat App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* --- 2. CUTE LAMP CSS ANIMATIONS --- */
        body {
            margin: 0;
            padding: 0;
            background-color: #2c3e50; 
            font-family: 'Times New Roman', serif;
            height: 100vh;
            overflow: hidden;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: background-color 0.5s;
        }

        body.light-on { background-color: #34495e; }

        .lamp-wrapper {
            position: absolute;
            top: -20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 10;
            width: 100px;
            display: flex;
            flex-direction: column;
            align-items: center;
            transform-origin: top center;
            animation: swing 3s ease-in-out infinite alternate;
        }

        @keyframes swing {
            from { transform: translateX(-50%) rotate(3deg); }
            to { transform: translateX(-50%) rotate(-3deg); }
        }

        .wire {
            width: 4px;
            height: 150px;
            background: #333;
            border-left: 2px solid #555;
        }

        .bulb-holder {
            width: 40px;
            height: 30px;
            background: #222;
            border-radius: 5px 5px 20px 20px;
            margin-top: -2px;
        }

        .bulb {
            width: 50px;
            height: 50px;
            background: #555;
            border-radius: 50%;
            margin-top: -15px;
            border: 2px solid #333;
            transition: all 0.3s;
            position: relative;
            z-index: 2;
        }

        .light-beam {
            position: absolute;
            top: 180px; 
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 0;
            background: radial-gradient(circle, rgba(255,255,200, 0.6) 0%, rgba(255,255,200, 0) 60%);
            border-radius: 50%;
            transition: all 0.5s ease;
            pointer-events: none; 
            z-index: 1;
            opacity: 0;
        }

        body.light-on .bulb {
            background: #ffeb3b;
            box-shadow: 0 0 30px #ffeb3b, 0 0 60px #ffeb3b;
            border-color: #ffeb3b;
        }

        body.light-on .light-beam {
            width: 800px;
            height: 800px;
            opacity: 1;
            top: 50px; 
        }

        /* --- FORM STYLING --- */
        .auth-card {
            background: rgba(0, 0, 0, 0.6); 
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 400px;
            color: white;
            position: relative;
            z-index: 5;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            transition: transform 0.3s;
        }

        body.light-on .auth-card {
            background: rgba(255, 255, 255, 0.95); 
            color: #333;
            transform: translateY(5px);
        }

        .form-control {
            background: rgba(255,255,255,0.1);
            border: none;
            color: white;
            padding: 12px;
            border-radius: 10px;
        }
        
        .form-control:focus {
            background: white;
            color: #333;
            box-shadow: none;
        }

        body.light-on .form-control {
            background: #f0f0f0;
            color: #333;
            border: 1px solid #ddd;
        }
        body.light-on .form-control:focus {
            background: white;
            border-color: #ff9933;
        }

        .btn-orange {
            background: #ff9933;
            color: white;
            font-weight: bold;
            border-radius: 10px;
        }
        .btn-orange:hover { background: #e68a00; color: white; }
        
        .toggle-link { cursor: pointer; color: #ff9933; font-weight: bold; }
        .toggle-link:hover { text-decoration: underline; }

        .d-none { display: none !important; }

        .text-error-custom { color: #ff6b6b !important; }
        body.light-on .text-error-custom { color: #dc3545 !important; }

        /* --- NEW: PASSWORD TOGGLE ICON --- */
        .password-toggle {
            position: absolute;
            right: 15px;
            top: 13px; /* Centers it vertically with the input */
            cursor: pointer;
            user-select: none;
            opacity: 0.7;
            transition: opacity 0.2s;
        }
        .password-toggle:hover {
            opacity: 1;
        }
    </style>
</head>
<body>

<div class="lamp-wrapper">
    <div class="wire"></div>
    <div class="bulb-holder"></div>
    <div class="bulb"></div>
</div>
<div class="light-beam"></div>

<div class="auth-card" id="mainCard">
    <div id="loginForm">
        <h3 class="fw-bold text-center mb-4">Welcome Back</h3>
        
        <div id="logGeneralError" class="text-error-custom small mb-3 text-center fw-bold form-error" style="display: none;"></div>

        <div class="mb-3">
            <input type="email" id="logEmail" class="form-control" placeholder="Email Address" onfocus="turnLightOn()" onblur="turnLightOff()">
            <div id="logEmailError" class="text-error-custom small mt-1 ms-1 form-error" style="display: none;"></div>
        </div>
        
        <div class="mb-3 position-relative">
            <input type="password" id="logPass" class="form-control pe-5" placeholder="Password" onfocus="turnLightOn()" onblur="turnLightOff()">
            <span class="password-toggle" onclick="togglePassword('logPass', this)">👁️</span>
            <div id="logPassError" class="text-error-custom small mt-1 ms-1 form-error" style="display: none;"></div>
        </div>
        
        <button onclick="handleAuth('login', event)" class="btn btn-orange w-100 py-3 mb-3">Login</button>
        <p class="text-center small">
            No account? <span class="toggle-link" onclick="toggleForm()">Register Now</span>
        </p>
    </div>

    <div id="regForm" class="d-none">
        <h3 class="fw-bold text-center mb-4">Join Bharat App</h3>

        <div id="regGeneralError" class="text-error-custom small mb-3 text-center fw-bold form-error" style="display: none;"></div>

        <div class="mb-3">
            <input type="text" id="regName" class="form-control" placeholder="Full Name" onfocus="turnLightOn()" onblur="turnLightOff()">
            <div id="regNameError" class="text-error-custom small mt-1 ms-1 form-error" style="display: none;"></div>
        </div>
        <div class="mb-3">
            <input type="email" id="regEmail" class="form-control" placeholder="Email Address" onfocus="turnLightOn()" onblur="turnLightOff()">
            <div id="regEmailError" class="text-error-custom small mt-1 ms-1 form-error" style="display: none;"></div>
        </div>

        <div class="mb-3 position-relative">
            <input type="password" id="regPass" class="form-control pe-5" placeholder="Password (Min 6 chars)" onfocus="turnLightOn()" onblur="turnLightOff()">
            <span class="password-toggle" onclick="togglePassword('regPass', this)">👁️</span>
            <div id="regPassError" class="text-error-custom small mt-1 ms-1 form-error" style="display: none;"></div>
        </div>
        
        <div id="regSuccessMsg" class="text-success small mb-3 text-center fw-bold" style="display: none;"></div>

        <button onclick="handleAuth('register', event)" class="btn btn-orange w-100 py-3 mb-3">Create Account</button>
        <p class="text-center small">
            Already have an account? <span class="toggle-link" onclick="toggleForm()">Login</span>
        </p>
    </div>
</div>

<script>
    function toggleForm() {
        document.getElementById('loginForm').classList.toggle('d-none');
        document.getElementById('regForm').classList.toggle('d-none');
        clearErrors(); 
        document.getElementById('regSuccessMsg').style.display = 'none';
        
        // Reset password fields to type="password" when switching forms
        document.getElementById('logPass').type = 'password';
        document.getElementById('regPass').type = 'password';
        document.querySelectorAll('.password-toggle').forEach(icon => icon.innerText = '👁️');
    }

    // --- NEW: Password Visibility Toggle ---
    function togglePassword(inputId, iconElement) {
        const input = document.getElementById(inputId);
        if (input.type === 'password') {
            input.type = 'text';
            iconElement.innerText = '🙈'; // Monkey hiding eyes (or you can use a crossed-out eye)
        } else {
            input.type = 'password';
            iconElement.innerText = '👁️';
        }
        // Keep the light on while clicking the icon
        turnLightOn();
        input.focus();
    }

    function turnLightOn() {
        document.body.classList.add('light-on');
    }

    function turnLightOff() {
        setTimeout(() => {
            const active = document.activeElement;
            const isInput = active.tagName === 'INPUT';
            if (!isInput) {
                document.body.classList.remove('light-on');
            }
        }, 100);
    }

    function showError(elementId, message) {
        const errorElement = document.getElementById(elementId);
        errorElement.innerText = message;
        errorElement.style.display = 'block';
    }

    function clearErrors() {
        const errorElements = document.querySelectorAll('.form-error');
        errorElements.forEach(el => {
            el.innerText = '';
            el.style.display = 'none';
        });
    }

    async function handleAuth(type, event) {
        clearErrors(); 
        let isValid = true;
        let formData = new URLSearchParams();
        
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const nameRegex = /^[a-zA-Z\s]+$/; 

        if (type === 'login') {
            const email = document.getElementById('logEmail').value.trim();
            const pass = document.getElementById('logPass').value;
            
            if (!email) { showError('logEmailError', 'Email is required.'); isValid = false; }
            else if (!emailRegex.test(email)) { showError('logEmailError', 'Please enter a valid email address.'); isValid = false; }
            
            if (!pass) { showError('logPassError', 'Password is required.'); isValid = false; }
            
            if (!isValid) return;

            formData.append('login', 'true');
            formData.append('email', email);
            formData.append('password', pass);
        } else {
            const name = document.getElementById('regName').value.trim();
            const email = document.getElementById('regEmail').value.trim();
            const pass = document.getElementById('regPass').value;
            
            if (!name) { showError('regNameError', 'Full name is required.'); isValid = false; }
            else if (!nameRegex.test(name)) { showError('regNameError', 'Only letters and spaces allowed.'); isValid = false; }

            if (!email) { showError('regEmailError', 'Email is required.'); isValid = false; }
            else if (!emailRegex.test(email)) { showError('regEmailError', 'Please enter a valid email address.'); isValid = false; }
            
            if (!pass) { showError('regPassError', 'Password is required.'); isValid = false; }
            else if (pass.length < 6) { showError('regPassError', 'Password must be at least 6 characters.'); isValid = false; }
            
            if (!isValid) return;

            formData.append('register', 'true');
            formData.append('full_name', name);
            formData.append('email', email);
            formData.append('password', pass);
        }

        const btn = event.target;
        const originalText = btn.innerText;
        btn.innerText = "Processing...";
        btn.disabled = true;

        try {
            const res = await fetch('auth.php', { method: 'POST', body: formData });
            const data = await res.json(); 

            if (data.status === 'success') {
                if (data.redirect) {
                    window.location.href = data.redirect;
                } else {
                    const successEl = document.getElementById('regSuccessMsg');
                    successEl.innerText = data.message;
                    successEl.style.display = 'block';

                    setTimeout(() => {
                        toggleForm();
                        document.getElementById('regName').value = '';
                        document.getElementById('regEmail').value = '';
                        document.getElementById('regPass').value = '';
                    }, 2000);
                }
            } else {
                showError(type === 'login' ? 'logGeneralError' : 'regGeneralError', data.message);
            }
        } catch (error) {
            console.error(error);
            showError(type === 'login' ? 'logGeneralError' : 'regGeneralError', "Connection error. Please try again.");
        } finally {
            btn.innerText = originalText;
            btn.disabled = false;
        }
    }
</script>

</body>
</html>