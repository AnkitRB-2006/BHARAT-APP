<?php 
session_start();
include 'includes/header.php'; 
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f4f6f9;
    }

    /* Premium Dark/Gold Hero Section */
    .plus-hero {
        background: linear-gradient(135deg, #1a1a1d 0%, #4e4e50 100%);
        color: white;
        padding: 80px 20px 60px;
        border-radius: 0 0 40px 40px;
        margin-top: -20px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        position: relative;
        overflow: hidden;
    }
    
    /* Subtle Gold Glow in Background */
    .plus-hero::before {
        content: '';
        position: absolute;
        top: -50%;
        left: 50%;
        width: 600px;
        height: 600px;
        background: radial-gradient(circle, rgba(255, 215, 0, 0.1) 0%, rgba(0,0,0,0) 70%);
        transform: translateX(-50%);
        z-index: 0;
    }

    .hero-content {
        position: relative;
        z-index: 1;
    }

    .text-gold { color: #FFD700 !important; }
    .bg-gold { background-color: #FFD700 !important; color: #1a1a1d !important; }

    /* Modern Pricing Cards */
    .plan-card {
        background: white;
        border: 2px solid transparent;
        border-radius: 24px;
        padding: 40px 30px;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        position: relative;
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    .plan-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.1);
    }
    .plan-card.popular {
        border-color: #ff9933;
        background: linear-gradient(180deg, #ffffff 0%, #fffaf5 100%);
    }
    .plan-card.popular:hover {
        box-shadow: 0 20px 40px rgba(255, 153, 51, 0.15);
    }

    /* Benefits Grid */
    .benefit-item {
        background: white;
        border-radius: 16px;
        padding: 20px;
        display: flex;
        align-items: center;
        gap: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.03);
        transition: 0.3s;
    }
    .benefit-item:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.08);
    }
    .benefit-icon {
        width: 50px;
        height: 50px;
        background: rgba(255, 153, 51, 0.1);
        color: #ff9933;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
    }

    /* Buttons */
    .btn-plus-outline {
        border: 2px solid #333;
        color: #333;
        font-weight: 600;
        border-radius: 30px;
        padding: 12px;
        transition: 0.3s;
    }
    .btn-plus-outline:hover {
        background: #333;
        color: white;
    }
    .btn-plus-primary {
        background: linear-gradient(45deg, #ff9933, #ff5e62);
        color: white;
        font-weight: 600;
        border: none;
        border-radius: 30px;
        padding: 12px;
        transition: 0.3s;
    }
    .btn-plus-primary:hover {
        transform: scale(1.05);
        box-shadow: 0 10px 20px rgba(255, 153, 51, 0.3);
        color: white;
    }
</style>

<div class="plus-hero mb-5 text-center">
    <div class="container hero-content">
        <div class="d-inline-block bg-dark border border-secondary rounded-pill px-4 py-2 mb-4">
            <span class="text-gold fw-bold"><i class="bi bi-star-fill me-2"></i>VIP Membership</span>
        </div>
        <h1 class="display-3 fw-bold mb-3">Bharat <span class="text-gold">Plus</span></h1>
        <p class="lead text-white-50 mx-auto" style="max-width: 600px;">
            Upgrade your lifestyle. Unlock unlimited free deliveries, exclusive discounts, and priority support across all Bharat App services.
        </p>
        <div class="mt-4">
            <span class="fs-5 fw-medium text-white">Average users save <span class="text-gold fw-bold">₹500+ Every Month</span></span>
        </div>
    </div>
</div>

<div class="container mb-5 pb-4">
    
    <div class="row g-4 justify-content-center mb-5 pb-3">
        <div class="col-md-5 col-lg-4">
            <div class="plan-card text-center">
                <h4 class="fw-bold text-dark mb-1">Monthly Plan</h4>
                <p class="text-muted small mb-4">Perfect for trying it out</p>
                
                <h1 class="display-4 fw-bold text-dark mb-0">₹99<span class="fs-5 text-muted fw-normal">/mo</span></h1>
                
                <div class="mt-4 mb-auto text-start">
                    <ul class="list-unstyled text-muted">
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-dark me-2"></i> Unlimited free deliveries</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-dark me-2"></i> Standard Plus discounts</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-dark me-2"></i> Cancel anytime</li>
                    </ul>
                </div>
                
                <button class="btn btn-plus-outline w-100 mt-4">Select Monthly</button>
            </div>
        </div>

        <div class="col-md-5 col-lg-4">
            <div class="plan-card popular text-center">
                <span class="badge bg-gold position-absolute top-0 start-50 translate-middle px-4 py-2 rounded-pill fw-bold shadow-sm" style="font-size: 0.9rem;">MOST POPULAR</span>
                
                <h4 class="fw-bold text-dark mb-1 mt-2">Quarterly Plan</h4>
                <p class="text-muted small mb-4">Best value for regulars</p>
                
                <h1 class="display-4 fw-bold mb-0" style="color: #ff9933;">₹249<span class="fs-5 text-muted fw-normal">/3mo</span></h1>
                <p class="text-success small fw-bold mt-1 mb-3 bg-success bg-opacity-10 d-inline-block px-3 py-1 rounded-pill">Save ₹48 instantly</p>
                
                <div class="mt-2 mb-auto text-start">
                    <ul class="list-unstyled text-dark fw-medium">
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-warning me-2"></i> Unlimited free deliveries</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-warning me-2"></i> Premium Plus discounts</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-warning me-2"></i> Priority VIP support</li>
                    </ul>
                </div>
                
                <button class="btn btn-plus-primary w-100 mt-4">Start 14-Day Free Trial</button>
            </div>
        </div>
    </div>

    <div class="text-center mb-5">
        <h3 class="fw-bold text-dark">What You Get with Plus</h3>
        <p class="text-muted">Experience the super app without limits.</p>
    </div>

    <div class="row g-4 justify-content-center px-lg-5">
        <div class="col-md-6">
            <div class="benefit-item">
                <div class="benefit-icon"><i class="bi bi-car-front-fill"></i></div>
                <div>
                    <h6 class="fw-bold mb-1">10% Cashback on All Rides</h6>
                    <p class="text-muted small mb-0">Save on every Yatra Auto, Bike, and Cab booking.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="benefit-item">
                <div class="benefit-icon"><i class="bi bi-box-seam-fill"></i></div>
                <div>
                    <h6 class="fw-bold mb-1">₹0 Delivery Fees</h6>
                    <p class="text-muted small mb-0">No delivery charges on Aahar, Kirana, and Dawai orders.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="benefit-item">
                <div class="benefit-icon"><i class="bi bi-headset"></i></div>
                <div>
                    <h6 class="fw-bold mb-1">Priority Customer Support</h6>
                    <p class="text-muted small mb-0">Skip the queue and connect with our top agents instantly.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="benefit-item">
                <div class="benefit-icon"><i class="bi bi-stars"></i></div>
                <div>
                    <h6 class="fw-bold mb-1">Early Access to Offers</h6>
                    <p class="text-muted small mb-0">Get exclusive sales and new features before anyone else.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>