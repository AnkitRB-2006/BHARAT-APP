<?php 
session_start();
include 'includes/header.php'; 
?>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f4f6f9;
    }

    /* Vibrant Yatra Hero Section */
    .yatra-hero {
        background: linear-gradient(135deg, #FFB75E 0%, #ED8F03 100%);
        color: #fff;
        padding: 60px 20px;
        border-radius: 0 0 40px 40px;
        margin-top: -20px;
        box-shadow: 0 10px 30px rgba(237, 143, 3, 0.2);
    }

    /* Booking Card */
    .booking-card {
        background: white;
        border-radius: 24px;
        border: none;
        box-shadow: 0 15px 35px rgba(0,0,0,0.08);
        padding: 30px;
        position: relative;
        z-index: 2;
    }

    /* Location Inputs styling to look like a connected route */
    .location-wrapper {
        position: relative;
        padding-left: 20px;
    }
    .location-wrapper::before {
        content: '';
        position: absolute;
        left: 5px;
        top: 25px;
        bottom: 25px;
        width: 2px;
        background-color: #e0e0e0;
        z-index: 1;
    }
    .location-input {
        background: #f8f9fa;
        border: 1px solid #e9ecef;
        border-radius: 12px;
        padding: 12px 15px;
        transition: 0.3s;
    }
    .location-input:focus {
        background: white;
        border-color: #ED8F03;
        box-shadow: 0 0 0 0.25rem rgba(237, 143, 3, 0.15);
    }
    
    /* Ride Options */
    .ride-option {
        border: 2px solid #f8f9fa;
        border-radius: 16px;
        padding: 15px;
        margin-bottom: 12px;
        cursor: pointer;
        transition: all 0.3s ease;
        background: white;
    }
    .ride-option:hover {
        border-color: #ffdfa0;
        background: #fffdf8;
    }
    .ride-option.active {
        border-color: #ED8F03;
        background: #fffaf0;
        box-shadow: 0 4px 15px rgba(237, 143, 3, 0.1);
    }
    .ride-icon {
        width: 50px;
        height: 50px;
        background: #f8f9fa;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.8rem;
    }

    /* Map Styling */
    .map-container {
        border-radius: 24px;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        border: 4px solid white;
        height: 550px;
        position: relative;
    }

    /* Primary Button */
    .btn-yatra {
        background-color: #212529;
        color: white;
        font-weight: 600;
        border-radius: 16px;
        transition: 0.3s;
    }
    .btn-yatra:hover {
        background-color: #ED8F03;
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(237, 143, 3, 0.3);
    }
</style>

<div class="yatra-hero mb-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-8">
                <span class="badge bg-dark text-white mb-2 px-3 py-2 rounded-pill fw-bold">Always on time</span>
                <h1 class="fw-bold mb-2 display-5"><i class="bi bi-car-front-fill"></i> Yatra Rides</h1>
                <p class="fs-5 opacity-75 mb-0">Book Autos, Bikes, and Cabs instantly for a smooth journey.</p>
            </div>
        </div>
    </div>
</div>

<div class="container mb-5">
    <div class="row g-5">
        
        <div class="col-lg-5">
            <div class="booking-card">
                <h4 class="fw-bold mb-4">Where to?</h4>
                
                <div class="location-wrapper mb-4">
                    <div class="position-relative mb-3">
                        <i class="bi bi-circle-fill text-success position-absolute" style="left: -20px; top: 15px; font-size: 0.6rem; z-index: 2;"></i>
                        <input type="text" class="form-control location-input fw-medium" placeholder="Current Location (Pickup)">
                    </div>
                    <div class="position-relative">
                        <i class="bi bi-square-fill text-danger position-absolute" style="left: -20px; top: 15px; font-size: 0.6rem; z-index: 2;"></i>
                        <input type="text" class="form-control location-input fw-medium" placeholder="Search Destination...">
                    </div>
                </div>

                <h6 class="fw-bold text-muted mb-3 mt-4">CHOOSE A RIDE</h6>
                
                <div class="ride-options-container mb-4">
                    
                    <div class="ride-option active d-flex justify-content-between align-items-center" onclick="selectRide(this, 'Auto', '127')">
                        <div class="d-flex align-items-center gap-3">
                            <div class="ride-icon text-warning">🛺</div>
                            <div>
                                <h6 class="fw-bold mb-0">Auto (ऑटो) <i class="bi bi-person-fill ms-1 text-muted small"></i> 3</h6>
                                <small class="text-muted">3-5 min away • Affordable</small>
                            </div>
                        </div>
                        <h5 class="fw-bold mb-0">₹127</h5>
                    </div>

                    <div class="ride-option d-flex justify-content-between align-items-center" onclick="selectRide(this, 'Bike', '83')">
                        <div class="d-flex align-items-center gap-3">
                            <div class="ride-icon text-primary">🏍️</div>
                            <div>
                                <h6 class="fw-bold mb-0">Bike (बाइक) <i class="bi bi-person-fill ms-1 text-muted small"></i> 1</h6>
                                <small class="text-muted">2-4 min away • Quickest</small>
                            </div>
                        </div>
                        <h5 class="fw-bold mb-0">₹83</h5>
                    </div>

                    <div class="ride-option d-flex justify-content-between align-items-center" onclick="selectRide(this, 'Cab', '215')">
                        <div class="d-flex align-items-center gap-3">
                            <div class="ride-icon text-dark">🚗</div>
                            <div>
                                <h6 class="fw-bold mb-0">Mini Cab <i class="bi bi-person-fill ms-1 text-muted small"></i> 4</h6>
                                <small class="text-muted">5-8 min away • Comfortable</small>
                            </div>
                        </div>
                        <h5 class="fw-bold mb-0">₹215</h5>
                    </div>
                </div>

                <button id="bookBtn" class="btn btn-yatra w-100 py-3 fs-5">Confirm Auto</button>
            </div>
        </div>

        <div class="col-lg-7">
            <div class="map-container mb-3">
                <div id="map" style="height: 100%; width: 100%;"></div>
                
                <div class="position-absolute bottom-0 start-50 translate-middle-x mb-4 w-75" style="z-index: 1000;">
                    <div class="bg-white p-3 rounded-4 shadow d-flex justify-content-between align-items-center">
                        <div>
                            <span class="small text-muted d-block">Estimated Distance</span>
                            <span class="fw-bold text-dark fs-5">8.5 km</span>
                        </div>
                        <span class="badge bg-success bg-opacity-10 text-success border border-success px-3 py-2 rounded-pill">
                            <i class="bi bi-shield-check me-1"></i> Verified Drivers
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    // Initialize Map
    var map = L.map('map').setView([12.9716, 77.5946], 14); // Centered on Bangalore
    
    // Add sleek custom tiles (CartoDB Positron for a cleaner look)
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap contributors &copy; CARTO'
    }).addTo(map);
    
    // Add Marker
    var driverMarker = L.marker([12.9716, 77.5946]).addTo(map)
        .bindPopup('<b>Nearest Driver</b><br>3 mins away').openPopup();

    // Interactive Ride Selection Logic
    function selectRide(element, rideType, price) {
        // Remove active class from all options
        let options = document.querySelectorAll('.ride-option');
        options.forEach(opt => opt.classList.remove('active'));
        
        // Add active class to clicked option
        element.classList.add('active');
        
        // Update the big booking button
        let btn = document.getElementById('bookBtn');
        btn.innerHTML = `Confirm ${rideType} • ₹${price}`;
    }
</script>

<?php include 'includes/footer.php'; ?>