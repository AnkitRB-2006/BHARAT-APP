<?php 
session_start();
include 'includes/header.php'; 
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f8f9fa;
    }

    /* Trustworthy B2B Hero Section */
    .partner-hero {
        background: linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%);
        color: white;
        padding: 80px 20px 100px;
        border-radius: 0 0 40px 40px;
        margin-top: -20px;
        position: relative;
        overflow: hidden;
    }
    
    .partner-hero::after {
        content: '';
        position: absolute;
        bottom: -50px;
        right: -50px;
        width: 300px;
        height: 300px;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 50%;
    }

    /* Category Cards */
    .partner-card {
        border: none;
        border-radius: 20px;
        background: white;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        text-align: center;
        padding: 40px 20px;
        height: 100%;
        position: relative;
        overflow: hidden;
    }
    .partner-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(44, 83, 100, 0.15);
    }
    .partner-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 5px;
        background: linear-gradient(90deg, #36D1DC 0%, #5B86E5 100%);
        opacity: 0;
        transition: 0.3s;
    }
    .partner-card:hover::before {
        opacity: 1;
    }

    .partner-icon {
        width: 80px;
        height: 80px;
        background: #f0f4f8;
        color: #2c5364;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2rem;
        margin: 0 auto 20px;
        transition: 0.3s;
    }
    .partner-card:hover .partner-icon {
        background: #2c5364;
        color: white;
        transform: scale(1.1);
    }

    /* Form Section */
    .join-form-card {
        background: white;
        border-radius: 24px;
        padding: 40px;
        box-shadow: 0 15px 40px rgba(0,0,0,0.08);
        border: 1px solid #e9ecef;
    }

    /* Future Updates Timeline/Grid */
    .future-card {
        background: linear-gradient(135deg, #ffffff 0%, #fcfdff 100%);
        border: 1px dashed #cbd5e1;
        border-radius: 20px;
        padding: 25px;
        transition: 0.3s;
        height: 100%;
    }
    .future-card:hover {
        border-color: #3b82f6;
        background: #f0f7ff;
    }
    .future-badge {
        background: #e2e8f0;
        color: #475569;
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 1px;
        padding: 5px 12px;
        border-radius: 20px;
        text-transform: uppercase;
    }

    /* Buttons */
    .btn-partner {
        background: linear-gradient(90deg, #36D1DC 0%, #5B86E5 100%);
        color: white;
        font-weight: 600;
        border: none;
        border-radius: 30px;
        padding: 12px 30px;
        transition: 0.3s;
    }
    .btn-partner:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(91, 134, 229, 0.4);
        color: white;
    }
</style>

<div class="partner-hero mb-5 text-center">
    <div class="container position-relative" style="z-index: 2;">
        <span class="badge bg-white text-dark mb-3 px-3 py-2 rounded-pill fw-bold shadow-sm">B2B Partnership</span>
        <h1 class="display-4 fw-bold mb-3">Grow Your Business with <span style="color: #36D1DC;">Bharat App</span></h1>
        <p class="lead text-white-50 mx-auto mb-4" style="max-width: 700px;">
            Join thousands of restaurants, stores, drivers, and service professionals who are multiplying their revenue through our unified super-app ecosystem.
        </p>
        <a href="#joinForm" class="btn btn-partner fs-5 mt-2">Become a Partner Today <i class="bi bi-arrow-right ms-2"></i></a>
    </div>
</div>

<div class="container pb-5">
    
    <div class="text-center mb-5">
        <h3 class="fw-bold text-dark">Who Can Partner With Us?</h3>
        <p class="text-muted">We have a specialized dashboard for every type of business.</p>
    </div>

    <div class="row g-4 mb-5 pb-4">
        <div class="col-md-4 col-lg-3">
            <div class="partner-card">
                <div class="partner-icon"><i class="bi bi-shop"></i></div>
                <h5 class="fw-bold text-dark">Merchants</h5>
                <p class="small text-muted mb-0">For Aahar, Kirana, Bazaar, Dawai, and Uphaar sellers.</p>
            </div>
        </div>
        <div class="col-md-4 col-lg-3">
            <div class="partner-card">
                <div class="partner-icon"><i class="bi bi-car-front-fill"></i></div>
                <h5 class="fw-bold text-dark">Drivers (Yatra)</h5>
                <p class="small text-muted mb-0">Auto, Bike, and Cab captains looking for zero-downtime rides.</p>
            </div>
        </div>
        <div class="col-md-4 col-lg-3">
            <div class="partner-card">
                <div class="partner-icon"><i class="bi bi-tools"></i></div>
                <h5 class="fw-bold text-dark">Professionals (Seva)</h5>
                <p class="small text-muted mb-0">Plumbers, electricians, cleaners, and salon experts.</p>
            </div>
        </div>
        <div class="col-md-4 col-lg-3">
            <div class="partner-card">
                <div class="partner-icon"><i class="bi bi-truck"></i></div>
                <h5 class="fw-bold text-dark">Delivery Fleet</h5>
                <p class="small text-muted mb-0">Delivery executives bridging our stores with customers.</p>
            </div>
        </div>
    </div>

    <div class="row g-5 align-items-center mb-5 pb-5" id="joinForm">
        <div class="col-lg-6">
            <h2 class="fw-bold text-dark mb-4">Why choose Bharat App?</h2>
            
            <div class="d-flex mb-4">
                <div class="me-3 fs-3 text-primary"><i class="bi bi-lightning-charge-fill"></i></div>
                <div>
                    <h5 class="fw-bold mb-1">Lightning Fast Payouts</h5>
                    <p class="text-muted small">Get your earnings settled directly to your bank account within 24 hours.</p>
                </div>
            </div>
            
            <div class="d-flex mb-4">
                <div class="me-3 fs-3 text-success"><i class="bi bi-graph-up-arrow"></i></div>
                <div>
                    <h5 class="fw-bold mb-1">Massive Customer Base</h5>
                    <p class="text-muted small">Tap into our unified ecosystem. A user booking a cab can easily order from your restaurant.</p>
                </div>
            </div>
            
            <div class="d-flex mb-4">
                <div class="me-3 fs-3 text-warning"><i class="bi bi-headset"></i></div>
                <div>
                    <h5 class="fw-bold mb-1">Dedicated Partner Support</h5>
                    <p class="text-muted small">24/7 priority support line dedicated strictly to resolving merchant and driver issues.</p>
                </div>
            </div>
        </div>
        
        <div class="col-lg-6">
            <div class="join-form-card">
                <h4 class="fw-bold mb-1">Request a Callback</h4>
                <p class="text-muted small mb-4">Fill out the details below and our onboarding team will reach out to you.</p>
                
                <form action="#" method="POST" onsubmit="event.preventDefault(); alert('Request submitted! Our team will contact you soon.');">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold text-muted">FULL NAME</label>
                            <input type="text" class="form-control form-control-lg bg-light" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold text-muted">PHONE NUMBER</label>
                            <input type="tel" class="form-control form-control-lg bg-light" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold text-muted">BUSINESS TYPE</label>
                            <select class="form-select form-select-lg bg-light" required>
                                <option value="" selected disabled>Select your category...</option>
                                <option>Restaurant / Cafe</option>
                                <option>Grocery / Supermarket</option>
                                <option>Retail / Electronics Shop</option>
                                <option>Pharmacy</option>
                                <option>Vehicle Owner / Driver</option>
                                <option>Home Service Professional</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold text-muted">CITY</label>
                            <input type="text" class="form-control form-control-lg bg-light" required>
                        </div>
                        <div class="col-12 mt-4">
                            <button type="submit" class="btn btn-partner w-100 py-3 fs-5">Submit Request</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="mt-5 pt-5 border-top">
        <div class="text-center mb-5">
            <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 rounded-pill fw-bold mb-2"><i class="bi bi-rocket-takeoff-fill me-1"></i> The Roadmap</span>
            <h3 class="fw-bold text-dark">Future Updates for Partners</h3>
            <p class="text-muted">We are constantly innovating. Here is what is coming to your Partner Dashboard soon.</p>
        </div>

        <div class="row g-4">
            <div class="col-md-6 col-lg-4">
                <div class="future-card">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="fs-2 text-primary"><i class="bi bi-robot"></i></div>
                        <span class="future-badge">Q3 2026</span>
                    </div>
                    <h5 class="fw-bold text-dark">AI Business Insights</h5>
                    <p class="text-muted small mb-0">Our AI will analyze your sales data to predict busy hours and suggest inventory restocks before you run out.</p>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="future-card">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="fs-2 text-success"><i class="bi bi-cash-coin"></i></div>
                        <span class="future-badge">Q4 2026</span>
                    </div>
                    <h5 class="fw-bold text-dark">Bharat Capital (Loans)</h5>
                    <p class="text-muted small mb-0">Instant, collateral-free micro-loans for shop expansions or vehicle maintenance based purely on your platform sales history.</p>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="future-card">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="fs-2 text-danger"><i class="bi bi-file-earmark-bar-graph"></i></div>
                        <span class="future-badge">Q1 2027</span>
                    </div>
                    <h5 class="fw-bold text-dark">Automated Tax Compliance</h5>
                    <p class="text-muted small mb-0">One-click generation of GST-compliant reports and automated ledger matching to make your accounting headache-free.</p>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-4">
                <div class="future-card">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="fs-2 text-warning"><i class="bi bi-star-fill"></i></div>
                        <span class="future-badge">In Development</span>
                    </div>
                    <h5 class="fw-bold text-dark">0% Commission Tier</h5>
                    <p class="text-muted small mb-0">A gamified tier system where top-rated partners with flawless delivery records temporarily unlock 0% platform commission days.</p>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-4">
                <div class="future-card">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="fs-2 text-info"><i class="bi bi-megaphone-fill"></i></div>
                        <span class="future-badge">In Development</span>
                    </div>
                    <h5 class="fw-bold text-dark">Self-Serve Ads Manager</h5>
                    <p class="text-muted small mb-0">Boost your store or restaurant's visibility directly from your app. Set a budget and appear at the top of customer search results.</p>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-4">
                <div class="future-card">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="fs-2 text-dark"><i class="bi bi-qr-code-scan"></i></div>
                        <span class="future-badge">Planning</span>
                    </div>
                    <h5 class="fw-bold text-dark">Offline POS Integration</h5>
                    <p class="text-muted small mb-0">Bharat App QR codes and POS hardware for your physical store to sync offline walk-in sales with your online dashboard.</p>
                </div>
            </div>
        </div>
    </div>

</div>

<?php include 'includes/footer.php'; ?>