<?php
include 'admin_auth.php';
include 'db.php';

$id = $_GET['id'];
$status = $_GET['status'];

$conn->query("UPDATE orders SET status='$status' WHERE id='$id'");
header("Location: admin-orders.php");