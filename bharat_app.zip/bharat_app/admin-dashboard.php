<?php
require_once 'admin_auth.php'; 
include 'db.php'; 

// --- 1. HANDLE ADD PRODUCT FORM SUBMISSION ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_product'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $service_type = $_POST['service_type'];
    
    $image_path = "uploads/default.png"; 

    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == 0) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
        
        $file_extension = pathinfo($_FILES["product_image"]["name"], PATHINFO_EXTENSION);
        $new_file_name = uniqid('img_') . '.' . $file_extension;
        $target_file = $target_dir . $new_file_name;
        
        if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
            $image_path = $target_file;
        }
    }

    $stmt = $conn->prepare("INSERT INTO products (name, price, service_type, image_path) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sdss", $name, $price, $service_type, $image_path);
    
    if ($stmt->execute()) {
        $success_msg = "Product successfully added to $service_type!";
    } else {
        $error_msg = "Failed to add product. Please try again.";
    }
}

// --- 2. FETCH OVERVIEW STATS ---
$users_count = 0;
$revenue = 0;

if ($conn) {
    $user_query = $conn->query("SELECT COUNT(*) as c FROM users");
    if ($user_query) $users_count = $user_query->fetch_assoc()['c'];

    if ($conn->query("SHOW TABLES LIKE 'orders'")->num_rows > 0) {
        $revenue_query = $conn->query("SELECT SUM(total) as s FROM orders");
        if ($revenue_query) $revenue = $revenue_query->fetch_assoc()['s'] ?? 0;
    }
}

// --- 3. FETCH DATA FOR GRAPHS (Last 6 Months) ---
$months_labels = [];
$revenue_data = [];
$users_data = [];

for ($i = 5; $i >= 0; $i--) {
    $month_name = date('M', strtotime("-$i months"));
    $months_labels[] = $month_name;
    $revenue_data[$month_name] = 0; 
    $users_data[$month_name] = 0;   
}

if ($conn) {
    if ($conn->query("SHOW TABLES LIKE 'orders'")->num_rows > 0) {
        $rev_query = $conn->query("
            SELECT DATE_FORMAT(created_at, '%b') as month_name, SUM(total) as monthly_rev 
            FROM orders 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH) 
            GROUP BY YEAR(created_at), MONTH(created_at)
        ");
        if($rev_query) {
            while($row = $rev_query->fetch_assoc()) {
                if(isset($revenue_data[$row['month_name']])) {
                    $revenue_data[$row['month_name']] = $row['monthly_rev'];
                }
            }
        }
    }

    $usr_query = $conn->query("
        SELECT DATE_FORMAT(created_at, '%b') as month_name, COUNT(id) as new_users 
        FROM users 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH) 
        GROUP BY YEAR(created_at), MONTH(created_at)
    ");
    if($usr_query) {
        while($row = $usr_query->fetch_assoc()) {
            if(isset($users_data[$row['month_name']])) {
                $users_data[$row['month_name']] = $row['new_users'];
            }
        }
    }
}

$js_months = json_encode(array_values($months_labels));
$js_revenue = json_encode(array_values($revenue_data));
$js_users = json_encode(array_values($users_data));

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Hub - Bharat App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { 
            background-color: #f4f7f6; 
            font-family: 'Poppins', sans-serif; 
        }
        
        .admin-nav { 
            background: linear-gradient(135deg, #001f3f 0%, #00152a 100%); 
            padding: 15px 0; 
        }
        .admin-nav .nav-link { 
            color: rgba(255, 255, 255, 0.7) !important; 
            font-weight: 500; 
            margin: 0 5px; 
            padding: 8px 16px;
            border-radius: 8px;
            transition: all 0.3s ease; 
        }
        .admin-nav .nav-link:hover { 
            color: #ffffff !important; 
            background: rgba(255, 255, 255, 0.1);
        }
        .admin-nav .active { 
            color: #ff9933 !important; 
            background: rgba(255, 153, 51, 0.1);
        }

        .hub-card { 
            border: 2px solid transparent; 
            border-radius: 24px; 
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); 
            padding: 35px 25px; 
            background: white; 
            text-align: left; 
            height: 100%;
            box-shadow: 0 4px 15px rgba(0,0,0,0.02);
        }
        .hub-card:hover { 
            transform: translateY(-8px); 
            box-shadow: 0 15px 30px rgba(0,0,0,0.06); 
            border-color: #ff9933;
        }
        
        .hub-icon { 
            font-size: 2.2rem; 
            margin-bottom: 20px; 
            display: inline-flex; 
            align-items: center;
            justify-content: center;
            width: 65px; 
            height: 65px; 
            border-radius: 18px; 
            transition: transform 0.3s ease;
        }
        .hub-card:hover .hub-icon { transform: scale(1.1); }
        
        .icon-orders { background: #e3f2fd; color: #1976d2; }
        .icon-users { background: #e8f5e9; color: #388e3c; }
        .icon-payments { background: #fff8e1; color: #f57f17; }
        .icon-inventory { background: #f3e5f5; color: #7b1fa2; }

        .stats-card {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            border-radius: 24px;
            border: 1px solid #e9ecef;
            box-shadow: 0 4px 15px rgba(0,0,0,0.02);
        }
        .stat-value {
            font-size: 2.5rem;
            font-weight: 700;
            letter-spacing: -1px;
        }

        .chart-container {
            background: white;
            border-radius: 24px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.02);
            border: 1px solid #e9ecef;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        /* Form Inputs Styling */
        .form-control, .form-select {
            border-radius: 12px;
            padding: 14px 18px;
            border: 1px solid #e0e0e0;
            background-color: #fcfcfc;
            transition: all 0.3s;
        }
        .form-control:focus, .form-select:focus {
            border-color: #ff9933;
            box-shadow: 0 0 0 4px rgba(255, 153, 51, 0.15);
            background-color: #ffffff;
        }
    </style>
</head>
<body>

<nav class="admin-nav shadow-sm mb-5">
    <div class="container d-flex justify-content-between align-items-center">
        <a class="navbar-brand text-white fw-bold fs-4" href="index.php">
            <i class="bi bi-cloud-fill me-2" style="color: #ff9933;"></i>Bharat App
        </a>
        <div class="d-flex align-items-center">
            <a class="nav-link active" href="admin-dashboard.php">Dashboard</a>
            <a class="nav-link" href="admin-orders.php">Manage Orders</a>
            <a class="nav-link" href="admin-products.php">Inventory</a>
            <a class="nav-link" href="admin-settings.php">Settings</a>
            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#addProductModal">+ Add Product</a>
            <a class="nav-link text-danger ms-3" href="admin_auth.php?logout=true" style="background: rgba(220,53,69,0.1);"><i class="bi bi-box-arrow-right me-1"></i> Logout</a>
        </div>
    </div>
</nav>

<div class="container py-4">
    
    <?php if(isset($success_msg)): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm border-0 rounded-4" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> <?php echo $success_msg; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if(isset($error_msg)): ?>
        <div class="alert alert-danger alert-dismissible fade show shadow-sm border-0 rounded-4" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i> <?php echo $error_msg; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-5">
        <div>
            <h2 class="fw-bold mb-0 text-dark">Welcome back, Admin 👋</h2>
            <p class="text-muted mt-1 mb-0">Here is what's happening with your platform today.</p>
        </div>
        <button class="btn btn-primary rounded-pill px-4 py-2 shadow-sm fw-bold" data-bs-toggle="modal" data-bs-target="#addProductModal" style="background: linear-gradient(45deg, #002147, #003a8c); border: none;">
            <i class="bi bi-plus-lg me-1"></i> Add New Product
        </button>
    </div>
    
    <div class="row g-4">
        <div class="col-md-3">
            <div class="card hub-card">
                <div class="hub-icon icon-orders"><i class="bi bi-cart-check"></i></div>
                <h5 class="fw-bold mb-2">Order Management</h5>
                <p class="text-muted small mb-0">Process live orders for Aahar, Kirana, and Bazaar.</p>
                <a href="admin-orders.php" class="stretched-link"></a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card hub-card">
                <div class="hub-icon icon-users"><i class="bi bi-people"></i></div>
                <h5 class="fw-bold mb-2">User Profiles</h5>
                <p class="text-muted small mb-0">Track logins, access levels, and activity history.</p>
                <a href="admin-users.php" class="stretched-link"></a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card hub-card">
                <div class="hub-icon icon-payments"><i class="bi bi-wallet2"></i></div>
                <h5 class="fw-bold mb-2">Payment History</h5>
                <p class="text-muted small mb-0">Review all historical transactions and served bills.</p>
                <a href="admin-payments.php" class="stretched-link"></a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card hub-card">
                <div class="hub-icon icon-inventory"><i class="bi bi-box-seam"></i></div>
                <h5 class="fw-bold mb-2">Inventory</h5>
                <p class="text-muted small mb-0">Edit names, prices, and update product images.</p>
                <a href="admin-products.php" class="stretched-link"></a>
            </div>
        </div>
    </div>

    <div class="row mt-5">
        <div class="col-12">
            <div class="stats-card p-4 p-md-5 d-flex flex-column flex-md-row justify-content-between align-items-md-center">
                <div class="mb-4 mb-md-0">
                    <h4 class="fw-bold mb-1"><i class="bi bi-graph-up-arrow text-primary me-2"></i> Platform Growth</h4>
                    <p class="text-muted mb-0">Live financial and user statistics.</p>
                </div>
                <div class="d-flex gap-4 gap-md-5">
                    <div class="px-3 border-end">
                        <small class="text-muted d-block text-uppercase fw-bold mb-1" style="letter-spacing: 1px;">Total Revenue</small>
                        <h3 class="stat-value text-success mb-0">₹<?php echo number_format($revenue); ?></h3>
                    </div>
                    <div class="px-3">
                        <small class="text-muted d-block text-uppercase fw-bold mb-1" style="letter-spacing: 1px;">Active Users</small>
                        <h3 class="stat-value text-dark mb-0"><?php echo number_format($users_count); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mt-4 mb-5 justify-content-center">
        <div class="col-md-6 col-lg-4">
            <div class="chart-container">
                <div class="w-100 d-flex justify-content-between align-items-center mb-3">
                    <h6 class="fw-bold text-dark m-0">Revenue (Last 6 Mos)</h6>
                    <i class="bi bi-currency-rupee text-success fs-5"></i>
                </div>
                <div class="w-100 position-relative">
                    <canvas id="revenueChart"></canvas>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 col-lg-4">
            <div class="chart-container">
                <div class="w-100 d-flex justify-content-between align-items-center mb-3">
                    <h6 class="fw-bold text-dark m-0">Users (Last 6 Mos)</h6>
                    <i class="bi bi-person-plus text-primary fs-5"></i>
                </div>
                <div class="w-100 position-relative">
                    <canvas id="usersChart"></canvas>
                </div>
            </div>
        </div>
    </div>

</div>

<div class="modal fade" id="addProductModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow-lg">
            <div class="modal-header bg-light border-0 rounded-top-4 p-4">
                <h5 class="modal-title fw-bold text-dark">Add New Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="admin-dashboard.php" method="POST" enctype="multipart/form-data">
                <div class="modal-body p-4">
                    <input type="hidden" name="add_product" value="1">
                    
                    <div class="mb-4">
                        <label class="form-label fw-bold text-muted small ms-1">SERVICE CATEGORY</label>
                        <select name="service_type" class="form-select" required>
                            <option value="" disabled selected>Select where to list this product...</option>
                            <option value="aahar">🍲 Aahar (Food Delivery)</option>
                            <option value="kirana">🥦 Kirana (Groceries)</option>
                            <option value="bazaar">🛍️ Bazaar (Shopping)</option>
                            <option value="uphaar">🎀 Uphaar (Gifts)</option>
                            <option value="dawai">💊 Dawai (Medicines)</option>
                            <option value="seva">🧹 Seva (Services)</option>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold text-muted small ms-1">PRODUCT NAME</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Masala Dosa or iPhone 15" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold text-muted small ms-1">PRICE (₹)</label>
                        <div class="input-group">
                            <span class="input-group-text fw-bold text-muted">₹</span>
                            <input type="number" name="price" class="form-control" placeholder="0.00" step="0.01" required>
                        </div>
                    </div>

                    <div class="mb-2">
                        <label class="form-label fw-bold text-muted small ms-1">PRODUCT PHOTO</label>
                        <input type="file" name="product_image" class="form-control" accept="image/*">
                        <small class="text-muted mt-2 ms-1 d-block"><i class="bi bi-info-circle me-1"></i> Select a high-quality image from your computer.</small>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-4 fw-medium" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-5 fw-bold" style="background-color: #002147; border: none;">Save Product</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    const monthLabels = <?php echo $js_months; ?>;
    const revenueData = <?php echo $js_revenue; ?>;
    const usersData = <?php echo $js_users; ?>;

    // Common options to force a perfect square shape
    const commonOptions = {
        responsive: true,
        maintainAspectRatio: true, 
        aspectRatio: 1, // <--- Forces the 1:1 Square Shape
        plugins: {
            legend: { display: false },
            tooltip: {
                backgroundColor: '#002147',
                padding: 10,
                titleFont: { family: 'Poppins' },
                bodyFont: { family: 'Poppins' }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: { borderDash: [4, 4], color: '#f0f0f5' },
                ticks: { font: { family: 'Poppins', size: 10 } }
            },
            x: {
                grid: { display: false },
                ticks: { font: { family: 'Poppins', size: 10 } }
            }
        }
    };

    // 1. Revenue Chart (Line with Marker)
    const ctxRev = document.getElementById('revenueChart').getContext('2d');
    new Chart(ctxRev, {
        type: 'line',
        data: {
            labels: monthLabels,
            datasets: [{
                label: 'Revenue (₹)',
                data: revenueData,
                borderColor: '#198754', // Success Green
                borderWidth: 2,
                backgroundColor: '#198754',
                pointBackgroundColor: '#ffffff', // White center
                pointBorderColor: '#198754',     // Green rim
                pointBorderWidth: 2,
                pointRadius: 6,       // Large prominent marker
                pointHoverRadius: 8,  // Even larger on hover
                fill: false,          // No fill beneath the line
                tension: 0.2          // Slight curve, mostly straight
            }]
        },
        options: {
            ...commonOptions,
            plugins: {
                ...commonOptions.plugins,
                tooltip: {
                    ...commonOptions.plugins.tooltip,
                    callbacks: {
                        label: function(context) { return '₹ ' + context.parsed.y.toLocaleString(); }
                    }
                }
            }
        }
    });

    // 2. User Growth Chart (Line with Marker)
    const ctxUsr = document.getElementById('usersChart').getContext('2d');
    new Chart(ctxUsr, {
        type: 'line',
        data: {
            labels: monthLabels,
            datasets: [{
                label: 'New Users',
                data: usersData,
                borderColor: '#0d6efd', // Primary Blue
                borderWidth: 2,
                backgroundColor: '#0d6efd',
                pointBackgroundColor: '#ffffff', // White center
                pointBorderColor: '#0d6efd',     // Blue rim
                pointBorderWidth: 2,
                pointRadius: 6,       // Large prominent marker
                pointHoverRadius: 8,
                fill: false,          // No fill beneath the line
                tension: 0.2          // Slight curve
            }]
        },
        options: {
            ...commonOptions,
            scales: {
                ...commonOptions.scales,
                y: {
                    ...commonOptions.scales.y,
                    ticks: { ...commonOptions.scales.y.ticks, stepSize: 1 } // Whole numbers only
                }
            }
        }
    });
</script>

</body>
</html>